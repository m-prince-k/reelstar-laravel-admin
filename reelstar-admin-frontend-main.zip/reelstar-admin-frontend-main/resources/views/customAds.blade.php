@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/customAds.js') }}"></script>
@endsection

@section('content')
    <div class="text-right mb-3">

    </div>

    <div class="card">

        <div class="card-header">
            <h4>{{ __('Custom Ads') }}</h4>

            <a href="{{ route('createCustomAd') }}" id="create_ad"
                class="ml-auto btn btn-primary">{{ __('Create Ad') }}</a>
        </div>

        <div class="card-body row">
            <div class="table-responsive col-12">
                <table class="table table-striped w-100" id="adsTable">
                    <thead>
                        <tr>
                            <th>{{ __('Ads Number') }}</th>
                            <th>{{ __('Title') }}</th>
                            <th>{{ __('Brand Name') }}</th>
                            <th>{{ __('Views') }}</th>
                            <th>{{ __('Clicks') }}</th>
                            <th>{{ __('Status') }}</th>
                            <th>{{ __('Platform') }}</th>
                            <th>{{ __('Ends On') }}</th>
                            <th>{{ __('Created at') }}</th>
                            <th>{{ __('Action') }}</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>


        </div>
    </div>

    </div>
@endsection
