@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/settings.js') }}"></script>
@endsection

@section('content')
    <div class="row">

        <div class="card col-12">
            <div class="card-header">
                <h4>{{ __('Settings') }}</h4>
                <div class="border-bottom-0 border-dark border"></div>
            </div>
            <div class="card-body">

                <form Autocomplete="off" class="form-group form-border" id="globalSettingsForm" action="" method="post">
                    @csrf
                    <input type="hidden" name="setting_id" value="{{ $data->setting_id ? $data->setting_id : '' }}" />
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="">{{ __('Currency') }}</label>
                            <input value="{{ $data->currency!=null || $data->currency!='undefined' ? $data->currency : '' }}" type="text" class="form-control" name="currency"
                                required>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="">{{ __('Coin Value (According to the Currency)') }}</label>
                            <input value="{{ $data->coin_value!=null ? $data->coin_value : '' }}" type="number" class="form-control"
                                name="coin_value" required>
                        </div>
                    </div>

                    <div class="form-row ">
                        <div class="form-group col-md-4">
                            <label for="">{{ __('Min. Fans For Popular Creator') }}</label>
                            <input type="number" class="form-control" name="min_fans_to_popular"
                                value="{{ $data->min_fans_to_popular!=null || $data->min_fans_to_popular!='undefined' ? $data->min_fans_to_popular : '' }}" required>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="">{{ __('Min. Fans For Verification') }}</label>
                            <input value="{{ $data->min_fans_verification!=null || $data->min_fans_verification!='undefined' ? $data->min_fans_verification : '' }}" type="number" class="form-control"
                                name="min_fans_verification" value="" required>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="">{{ __('Min. Coins To Redeem') }}</label>
                            <input value="{{ $data->min_redeem_coins!=null || $data->min_redeem_coins!='undefined' ? $data->min_redeem_coins : '' }}" type="number" class="form-control"
                                name="min_redeem_coins" value="" required>
                        </div>
                    </div>

                    <div class="form-row ">
                        <div class="form-group col-md-4">
                            <label for="">{{ __('Reward : Daily Check-In') }}</label>
                            <input type="number" class="form-control" name="reward_daily_check_in"
                                value="{{ $data->reward_daily_check_in!=null || $data->reward_daily_check_in!='undefined' ? $data->reward_daily_check_in: '' }}" required>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="">{{ __('Reward : Video Upload') }}</label>
                            <input value="{{ $data->reward_video_upload!=null || $data->reward_video_upload!='undefined' ? $data->reward_video_upload : '' }}" type="number" class="form-control"
                                name="reward_video_upload" value="" required>
                        </div>
						
                        <div class="form-group col-md-4">
                            <label for="">{{ __('Maximum Videos User Can Upload Daily') }}</label>
                            <input value="{{ $data->max_upload_daily!=null || $data->max_upload_daily!='undefined' ? $data->max_upload_daily : '' }}" type="number" class="form-control"
                                name="max_upload_daily" value="" required>
                        </div>
						
                    </div>
                    
                    <div class="form-row ">
                        <div class="form-group col-md-6">
                            <label for="">{{ __('Android Version') }}</label>
                            <input type="text" class="form-control" name="AndroidVersion"
                                value="{{ $data->androidversion!=null || $data->androidversion!='undefined' ? $data->androidversion : '' }}" required>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">{{ __('Ios Version') }}</label>
                            <input value="{{ $data->iosversion!=null || $data->iosversion!='undefined' ? $data->iosversion : '' }}" type="text" class="form-control"
                                name="IosVersion" value="" required>
                        </div>


                        <div class="form-group col-md-6">
                            <label for="">{{ __('Post Like') }}</label>
                            <input value="{{ $data->post_like!=null || $data->post_like!='undefined' ? $data->post_like : '' }}" type="text" class="form-control"
                                name="post_like" value="">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">{{ __('Post Comment') }}</label>
                            <input value="{{ $data->post_comment!=null || $data->post_comment!='undefined' ? $data->post_comment : '' }}" type="text" class="form-control"
                                name="post_comment" value="">
                        </div>



                    </div>

                    <div class="form-row ">
                        <div class="form-group col-md-3">
                            <label for="">{{ __('Admob Native Ad-Unit Android') }}</label>
                            <input type="text" class="form-control" name="admob_native"
                                value="{{ $data->admob_native!=null || $data->admob_native!='undefined' ? $data->admob_native : '' }}">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="">{{ __('Admob Native Ad-Unit IOS') }}</label>
                            <input type="text" class="form-control" name="admob_native_ios"
                                value="{{ $data->admob_native_ios!=null || $data->admob_native_ios!='undefined' ? $data->admob_native_ios : ''}}">
                        </div>
                        <div class="form-group col-md-3">
                            <label class="d-block" for="">{{ __('Show Ads In App') }}</label>
                            <label class="switch ml-1">
                                <input type="checkbox" name="featured" id="adsSwitch"
                                    {{ $data->ads_enabled == 1 ? 'checked' : '' }}>
                                <span class="slider round"></span>
                            </label>
                        </div>
                        <!-- <div class="form-group col-md-3">
                            <label class="d-block"
                                for="">{{ __('Use DeepAR Camera (Off= Simple Camera)') }}</label>
                            <label class="switch ml-1">
                                <input type="checkbox" name="is_deepar_on" id="deepARSwitch"
                                    {{ $data->is_deepar_on == 1 ? 'checked' : '' }}>
                                <span class="slider round"></span>
                            </label>
                        </div> -->
                    </div>
                    <div class="my-4">
                        <h5 class="text-dark">{{ __('Livestream Control') }}</h5>
                        <spanm>If you set any of the below values to <strong>0</strong> The livestream Timeout function will
                            stop working.</span>
                    </div>
                    <div class="form-row ">
                        <div class="form-group col-md-4">
                            <label for="">{{ __('Minimum Viewers Required (To Contine Livestreaming)') }}</label>
                            <input type="number" class="form-control" name="live_min_viewers"
                                value="{{ $data->live_min_viewers!=null  || $data->live_min_viewers!='undefined' ? $data->live_min_viewers : '' }}">
                        </div>
                        <div class="form-group col-md-4">
                            <label
                                for="">{{ __("Livestream Timeout Minutes (if don't get minimum viewers)") }}</label>
                            <input type="number" class="form-control" name="live_timeout"
                                value="{{ $data->live_timeout!=null || $data->live_timeout!='undefined' ? $data->live_timeout : '' }}">
                        </div>
                        <!-- <div class="form-group col-md-4">
                            <label class="d-block"
                                for="">{{ __('Multiple hosts in livestream') }}</label>
                            <label class="switch ml-1">
                                <input type="checkbox" name="is_multiple_livestream_on" id="multipleLivestreamSwitch"
                                    {{ $data->is_multiple_livestream_on == 1 ? 'checked' : '' }}>
                                <span class="slider round"></span>
                            </label>
                        </div> -->

                    </div>

                    <div class="my-4">
                        <h5 class="text-dark">{{ __('Maintenance Control') }}</h5>
                        <span>can decide the maintenance mode ?</span>
                    </div>
                
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="">{{ __('App Status') }}</label>
                            <select id="maintenace" class="form-control" name="app_status" id="app_status">
                                <option disabled>App Status</option>
                                <option value="maintenance" <?php $data->app_status=='maintenance' ? 'selected' : '' ?>>Maintenance</option>
                                <option value="live" <?php $data->app_status=='live' ? 'selected' : '' ?>>Live</option>
                                <option value="development" <?php $data->app_status=='development' ? 'selected' : '' ?>>Development</option>
                            </select>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="">{{ __('App Url') }}</label>
                            <input type="text" class="form-control" placeholder="App Url" maxlength="150" value="{{$data->app_url ? : ''}}" name="app_url" id="app_url" />
                        </div>

                        <div class="form-group col-md-4">
                            <label for="">{{ __('App Message') }}</label>
                            <textarea placeholder="App Message" class="form-control" id="app_message" name="app_message" maxlength="150" style="resize:none" value="{{$data->app_message ?? '' }}">{{$data->app_message ?? '' }}</textarea>
                        </div>

                    </div>



                    <div class="form-group-submit">
                        <button class="btn btn-primary " type="submit">{{ __('Save') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
