@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/index.js') }}"></script>
@endsection



@section('content')
    <style>
        .chartjs-render-monitor {
            -webkit-animation: chartjs-render-animation 0.001s;
            animation: chartjs-render-animation 0.001s;
        }

        *,
        ::after,
        ::before {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
        }

        .mainbg {
            background-image: linear-gradient(#FF6D6D, #FF4545) !important;
        }

        .card-icon2 {
            width: 50px;
            height: 50px;
            line-height: 50px;
            font-size: 22px;
            margin: 5px 0px;
            box-shadow: 2px 2px 10px 0 #97979794;
            border-radius: 10px;
            background: #6777ef;
            text-align: center;
        }

        i {
            font-size: 20px !important;
        }

        .maincolor {
            color: white !important;
        }

    </style>



    <section class="section">
        <div class="row col-12">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-user maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('All Users') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["users"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-camera-retro maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Livestream Enabled Users') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["liveStreamEligible"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-check-circle maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Verified Users') }}</h5>
                                        <h3 class="mb-3 "> {{$dashboard["verified"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-ban maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Blocked Users') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["blockUser"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>

        <div class="row col-12">

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-film maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Total Posts') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["posts"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-music maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Sound Categories') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["soundCategory"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-music maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Sounds') }}</h5>
                                        <h3 class="mb-3 "> {{$dashboard["sounds"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-box maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Coin Plans') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["coins"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="row col-12">

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-money-bill-alt maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Redeem Requests') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["radeemRequests"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-video maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Livestream Requests') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["liveRequests"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-check-circle maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Verification Requests') }}</h5>
                                        <h3 class="mb-3 "> {{$dashboard["verifyRequests"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-flag maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Post Reports') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["postReports"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
           

        </div>
        <div class="row col-12">

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-flag maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('User Reports') }}</h5>
                                        <h3 class="mb-3 ">{{$dashboard["reportUsers"] ?? 0}}</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <!-- <h5 class="ml-4">Ads</h5> -->
        <!-- <div class="row col-12">

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-flag maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Total Custom Ads') }}</h5>
                                        <h3 class="mb-3 ">asfasfa</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-flag maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Running Custom Ads') }}</h5>
                                        <h3 class="mb-3 ">asfasf</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-flag maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('Android Running Ads') }}</h5>
                                        <h3 class="mb-3 ">afasfa</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                    <div class="card-icon2 mainbg">
                                        <i class="fas fa-flag maincolor"></i>
                                    </div>
                                    <div class="card-content">
                                        <h5 class="font-15 mt-3">{{ __('iOS Running Ads') }}</h5>
                                        <h3 class="mb-3 ">afafa</h3>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

      



    </section>


@endsection
