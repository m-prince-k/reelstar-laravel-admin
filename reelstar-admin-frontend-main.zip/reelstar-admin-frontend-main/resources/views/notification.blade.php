@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/notification.js') }}"></script>
@endsection

@section('content')
<style>
    .chosen-container.chosen-container-multi {
    width: 470px !important;
}
</style>
    <div class="card">

        <div class="card-header">
            <h4>{{ __('Notifications') }}</h4>
            <div class="text-right ml-auto">

           
                <a class="btn btn-primary addModalBtn" data-toggle="modal" id="addItem" data-target="#additem"
                    href="">{{ __('New Notification') }}
                </a>

            </div>
        </div>

        <div class="card-body row">
            <div class="table-responsive col-12">
                <table class="table table-striped w-100" id="table-22">
                    <thead>
                        <tr>
                            <th> {{ __('Title') }}</th>
                            <th> {{ __('Message') }}</th>
                            <th> {{ __('Action') }}</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>

        {{-- Add Modal --}}
        <div class="modal fade" id="additem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4>{{ __('New Notification') }}</h4>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                <form action="" method="post" class="" id="addForm"
                            autocomplete="off">
                            @csrf
                            <div class="form-group">
                                <label> {{ __('Title') }}</label>
                                <input type="text" name="title" id="title" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label> {{ __('Message') }}</label>
                                <textarea type="text" name="message" id="message" class="form-control" required></textarea>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" value="All Users" id="all_selected_users" onclick="toggle('#select_the_users_chosen', this)" name="all_users" />
                                <label class="notify_specific_user">All Users</label>
                            </div>
                            <div class="form-group">
                            <!-- <div class="container" style="border:2px solid #ccc; width:300px; height: 100px; overflow-y: scroll;">
    <input type="checkbox" id="all_users" /><br />
</div> -->
                            <!-- <select data-placeholder="Select the users" id="select_the_users" multiple class="chosen-select" name="test">
    <option value=""></option>
    <option>American Black Bear</option>
    <option>Asiatic Black Bear</option>
    <option>Brown Bear</option>
    <option>Giant Panda</option>
    <option>Sloth Bear</option>
    <option>Sun Bear</option>
    <option>Polar Bear</option>
    <option>Spectacled Bear</option>
  </select> -->
                            </div>

                            <!-- <div class="form-group">
                                <select id="no_of_level" class="form-control">
                                    <option value="select the user">select the user</option>
                                    <option value="1000">1000</option>
                                    <option value="3000">3000</option>
                                </select>
                            </div> -->

                            <div class="form-group">
                                <input class="btn btn-primary mr-1" id="submitNotificationForm" type="submit" value=" {{ __('Submit') }}">
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>

        {{-- Edit Modal --}}
        <div class="modal fade" id="edititem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4>{{ __('Edit Notification') }}</h4>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form action="" method="post" class="add_category" id="editForm"
                            autocomplete="off">
                            @csrf

                            <input type="hidden" class="form-control" id="editId" name="admin_notf_id" value="">

                            <div class="form-group">
                                <label> {{ __('Title') }}</label>
                                <input id="edit_title" type="text" name="title" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label> {{ __('Message') }}</label>
                                <textarea id="edit_message" type="text" name="message" class="form-control" required></textarea>
                            </div>

                            <div class="form-group">
                                <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>
        <script type="text/javascript">
    //$(document).ready(function() {
        $(".chosen-select").chosen({
            no_results_text: "Oops, nothing found!"
        })

        function toggle(className, obj) {
            var $input = $(obj);
            if ($input.prop('checked')){
                $(className).hide();
            }
            else {
                $(className).show();
            }
        } 
    
   // });
</script>
    @endsection
