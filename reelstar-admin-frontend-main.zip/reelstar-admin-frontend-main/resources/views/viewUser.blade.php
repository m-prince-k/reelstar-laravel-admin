@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/viewUser.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('asset/style/edituser.css') }}">
@endsection



@section('content')
    <input type="hidden" class="form-control" id="userId" name="userId" value="{{isset($user['user_id']) ? $user['user_id'] : Request::segment(2) }}">

    <div class="card">
        <div class="card-header">
        <h4> {{$user['fullname'] ?? 'N/A' }}</h4>
                <span class="badge bg-danger text-white badge-shadow "></span>
       
            <div class="d-flex ml-auto">
                    @if($user['is_verified']==0 || $user['is_verified']==null)
                    <button class='btn btn-danger verify-user ml-2'>{{ __('Verify User') }}</button>
                    @elseif($user['is_verified']==1)
                    <button class='btn btn-success verify-user ml-2'>{{ __('Already Verified') }}</button>
                    @endif

                <button class='btn btn-primary edit-user ml-2'>{{ __('Edit User') }}</button>
          
             
                @if($user['livestream_eligible']==false || $user['livestream_eligible']==null)
                <button  class='btn btn-danger enabled_live_streaming ml-2'>{{ __('Enable Livestreaming') }}</button>
                @elseif($user['livestream_eligible']==true)
                <button  class='btn btn-success enabled_live_streaming ml-2'>{{ __('Disable Livestreaming') }}</button> 
                @endif
               
        
                @if($user['is_sponsored']==false || $user['is_sponsored']==null)
                <button  class='btn btn-danger enabled_sponsor ml-2'>{{ __('Enable Sponsored') }}</button>
                @elseif($user['is_sponsored']==true)
                <button  class='btn btn-success enabled_sponsor ml-2'>{{ __('Disable Sponsored') }}</button>
                @endif
              
            </div>
        </div>



        <div class="card-body">
                @if(isset($user['profile_image']))
                @if($user['profile_image']==null)
                <img class="rounded m-1" src="http://placehold.jp/150x150.png" width="130" height="130">
                @else 
                <img class="rounded m-1" src="https://d3ffhcda3vxwnb.cloudfront.net/{{$user['profile_image']}}" width="130"
                    height="130">
                @endif    
            @endif            



            <div class="form-row mt-3">
                <div class="form-group col-md-4">
                    <label>{{ __('Username') }}</label>
                    <input class="form-control" value="{{$user['username'] ?? ''}}" readonly>
                </div>
                <div class="form-group col-md-4">
                    <label>{{ __('Identity') }}</label>
                    <input class="form-control" value="{{$user['identity'] ?? ''}}" readonly>
                </div>
                <div class="form-group col-md-4">
                    <label>{{ __('Fullname') }}</label>
                    <input class="form-control" value="{{$user['fullname'] ?? ''}}" readonly>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-4">
                    <label>{{ __('Bio') }}</label>
                    <input class="form-control" value="{{$user['bio'] ?? ''}}" readonly>
                </div>

            </div>

            <div class="mt-1">

                <p class="mb-1">{{ __('Other Details') }}</p>

                <div class="title-tag d-inline py-2 px-3 ">
                    <p class="d-inline">{{ __('Total Likes') }} : {{$user['total_like'] ?? 0}}</p>
                </div>
                <div class="title-tag d-inline py-2 px-3 ml-2">
                    <p class="d-inline">{{ __('Total Followers') }} : {{$user['total_followers'] ?? 0}}</p>
                </div>
                <div class="title-tag d-inline py-2 px-3 ml-2">
                    <p class="d-inline">{{ __('Device Type') }} : 
                    @if(isset($user['device_Type']))    
                    @if($user['device_Type']==1)
                        ANDROID
                        @elseif($user['device_Type']==2)
                            IOS
                        @endif
                    @endif    
                    </p>
                </div>

            </div>
            <!-- <div class="mt-3">

                <p class="mb-1">{{ __('Wallet Details') }}</p>
                <div class="title-tag d-inline py-2 px-3">
                    <p class="d-inline">{{ __('Coins') }} : </p>
                </div>
                <div class="title-tag d-inline py-2 px-3 ml-2">
                    <p class="d-inline">{{ __('Total Received') }}</p>
                </div>
                <div class="title-tag d-inline py-2 px-3 ml-2">
                    <p class="d-inline">{{ __('Total Spent') }} </p>
                </div>
                <div class="title-tag d-inline py-2 px-3 ml-2">
                    <p class="d-inline">{{ __('From Daily Check-in') }} </p>
                </div>
                <div class="title-tag d-inline py-2 px-3 ml-2">
                    <p class="d-inline">{{ __('From Video Upload') }} </p>
                </div>
                <div class="title-tag d-inline py-2 px-3 ml-2">
                    <p class="d-inline">{{ __('From Fans') }}</p>
                </div>
                <div class="title-tag d-inline py-2 px-3 ml-2">
                    <p class="d-inline">{{ __('Purchased') }}</p>
                </div>


            </div> -->

            <div class="form-row">

            </div>

        </div>
    </div>

    <div class="card">

        <div class="card-header">
            <h4>{{ __('User Posts') }}</h4>

        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped" id="viewPostByUser">
                    <thead>
                        <tr>
                      
                            <th>{{ __('Content') }}</th>
                            <th>{{ __('Thumbnail') }}</th>
                            <th>{{ __('Identity') }}</th>
                            <th>{{ __('Username') }}</th>
                            <th>{{ __('Description') }}</th>
                            <th>{{ __('Views') }}</th>
                            <th>{{ __('Likes') }}</th>
                            <th>{{ __('Created at') }}</th>
                            <th>{{ __('Action') }}</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- Edit User Modal --}}
    <div class="modal fade" id="editUserItem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>{{ __('Edit User') }}</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    

                    <form action="" method="post" enctype="multipart/form-data"  id="editUserForm"
                        autocomplete="off">
                        @csrf
                        <input type="hidden" class="form-control" id="userId" name="id" value="{{$user['user_id'] ?? ''}}">
                @if(isset($user['profile_image']))
                @if($user['profile_image']==null)
                @if(str_contains($user['profile_image'],"https://d3ffhcda3vxwnb.cloudfront.net"))
                    <img class="rounded m-1" src="{{$user['profile_image']}}" id="profile_img_preview" width="130"
                    height="130">
                @else
                    <img class="rounded m-1" src="https://d3ffhcda3vxwnb.cloudfront.net/{{$user['profile_image']}}" id="profile_img_preview" width="130"
                    height="130">
                @endif
                    @else 
                    <img class="rounded m-1" src="http://placehold.jp/150x150.png" width="130" id="profile_img_preview" height="130">
              
                @endif 
                @endif
                        <!-- <div class="form-group">
                            <div class="mb-3">
                                <label for="profile_image" class="form-label">{{ __('Image') }}</label>
                                <input class="form-control" type="file" id="profile_image" name="profile_image">
                            </div>
                        </div> -->

                        <div class="form-group">
                            <label> {{ __('Fullname') }}</label>
                            <input value="{{$user['fullname'] ?? ''}}" id="edit_fullname" type="text" name="fullname"
                                class="form-control" required>
                        </div>
						
						<div class="form-group">
                            <label> {{ __('Maximum Videos User Can Upload Daily') }}</label>
                            <input value="20" id="edit_max_upload_daily" type="number"
                                class="form-control" required>
                        </div>
						

                        <div class="form-group">
                            <label> {{ __('Bio') }}</label>
                            <textarea  type="text" name="bio" value="{{$user['bio'] ?? ''}}" id="userBio" class="form-control">{{$user['bio'] ?? ''}}</textarea>
                        </div>

                        <div class="form-group">
                            <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    {{-- Video Modal --}}
    <div class="modal fade" id="video_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>{{ __('View Content') }}</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="videoDesc"></p>
                    <video rel="" id="video" width="450" height="450" controls>
                        <source src="" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>

            </div>
        </div>
    </div>

    {{-- Add coin modal --}}
    <div class="modal fade" id="addCoinModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <h3>{{ __('Add Coins') }}</h3>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="" method="post" enctype="multipart/form-data" class="add_category" id="addCoinForm"
                        autocomplete="off">
                        @csrf
                        <input value="" type="hidden" class="form-control" id="addcoinUserId"
                            name="id" value="">
                        {{-- <div class="form-group">
                            <label> {{ __('app.Title') }}</label>
                            <input type="text" name="title" class="form-control" required>
                        </div> --}}


                        <div class="form-group">
                            <label> {{ __('Coins') }}</label>
                            <input id="amount" type="number" name="amount" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Add Coins') }}">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    {{-- Image modal --}}
    <div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <h4>{{ __('View Content') }}</h4>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="viewDesc"></p>
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators" id="indicator-place">
                            {{-- <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li> --}}

                        </ol>

                        <div class="carousel-inner" id="image-place">

                            {{-- <div class="carousel-item active">
                            <img class="d-block w-100" src="..." >
                          </div> --}}

                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection
