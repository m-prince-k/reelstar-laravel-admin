@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/createCustomAd.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('asset/style/createads.css') }}">
@endsection

@section('content')
    <input type="hidden" class="form-control" id="userId" name="userId" value="">

    <div class="card">
        <div class="card-header">
            <h4>
                {{ __('Create Custom Ad') }}
            </h4>

        </div>

        <div class="card-body">
            <form action="" method="post" enctype="multipart/form-data" id="createCampaignForm" autocomplete="off">
                @csrf

                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label>{{ __('Campaign Title (For Reference Only)') }}</label>
                        <input name="ads_title" class="form-control" value="" required>
                    </div>
                </div>

                <div class="form-row ">
                    <div class="form-group col-md-6">
                        <label>{{ __('Brand Name') }}</label>
                        <input id="brand_name" name="brand_name" class="form-control" value="" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label>{{ __('Headline') }}</label>
                        <input id="headline" name="headline" class="form-control" value="" required>
                    </div>
                </div>

                <div class="form-row ">
                    <div class="form-group col-md-6">
                        <label>{{ __('Description') }}</label>
                        <textarea id="description" name="description" class="form-control" value="" required></textarea>
                    </div>
                    <div class="form-group col-md-6 d-flex">
                        <img height="65" width="65" class="rounded mt-4" id="brand_logo_img"
                            src="http://placehold.jp/150x150.png" alt="">

                        <div class="form-group col-md-6 mt-3">
                            <label for="brand_logo" class="form-label">{{ __('Brand Logo') }}</label>
                            <input class="form-control" type="file" id="brand_logo" name="brand_logo"
                                accept="image/png, image/gif, image/jpeg" required>
                        </div>
                    </div>
                </div>
                <div class="form-row ">
                    <div class="form-group col-md-4">
                        <label>{{ __('Button Text') }}</label>
                        <input name="button_text" class="form-control" value="" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label>{{ __('Button Color') }}</label>
                        <input type="color" name="button_color" class="form-control" value="" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label>{{ __('End Date') }}</label>
                        <input min="<?php echo date('Y-m-d'); ?>" type="date" name="end_date" class="form-control" value=""
                            required>
                    </div>
                </div>

                <div class="form-row mx-xl-1 ">
                    {{-- Android Link --}}
                    <div class="form-row bg-link mr-xl-1  col-xl">
                        <div class="form-group col-md-2">
                            <label class="d-block" for="">{{ __('For Android') }}</label>
                            <label class="switch ">
                                <input type="checkbox" name="is_android" id="androidSwitch">
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="form-group col-md-10">
                            <label>{{ __('Android Link') }}</label>
                            <input id="android_link" type="text" name="android_link" class="form-control" value=""
                                disabled>
                        </div>
                    </div>

                    {{-- iOS Link --}}
                    <div class="form-row bg-link ml-xl-1 mt-2 mt-xl-0 col-xl">
                        <div class="form-group col-md-2">
                            <label class="d-block" for="">{{ __('For iOS') }}</label>
                            <label class="switch ">
                                <input type="checkbox" name="is_ios" id="iosSwitch">
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="form-group col-md-10">
                            <label>{{ __('iOS Link') }}</label>
                            <input id="ios_link" name="ios_link" class="form-control" value="" disabled>
                        </div>
                    </div>
                </div>

                {{-- Images and video Preview --}}
                <div class="form-row">
                    {{-- Horizintal Image --}}
                    <div class="form-group col-md-4">
                        <img height="120" width="120" class="rounded mt-4" id="horizontal_image_img"
                            src="http://placehold.jp/150x150.png" alt="">
                    </div>
                    {{-- Vertical Image --}}
                    <div class="form-group col-md-4">
                        <img height="120" width="120" class="rounded mt-4" id="vertical_image_img"
                            src="http://placehold.jp/150x150.png" alt="">
                    </div>

                </div>

                {{-- Images and video --}}
                <div class="form-row">
                    {{-- Horizintal Image --}}
                    <div class="form-group col-md-4">
                        <label for="horizontal_image" class="form-label">{{ __('Horizontal Image') }}</label>
                        <input class="form-control" type="file" id="horizontal_image" name="horizontal_image"
                            accept="image/png, image/gif, image/jpeg" required>
                    </div>
                    {{-- Vertical Image --}}
                    <div class="form-group col-md-4">
                        <label for="vertical_image" class="form-label">{{ __('Vertical Image') }}</label>
                        <input class="form-control" type="file" id="vertical_image" name="vertical_image"
                            accept="image/png, image/gif, image/jpeg" required>
                    </div>
                    {{-- Video --}}
                    <div class="form-group col-md-4">
                        <label for="video" class="form-label">{{ __('Video') }}</label>
                        <input class="form-control" type="file" id="video" name="video"
                            accept="video/mp4,video/x-m4v,video/*">
                    </div>
                </div>

                <div class="form-group d-flex justify-content-end">
                    <button id="btn_cancel" class="btn btn-danger  mr-2">{{ __('Cancel') }}</button>
                    <input class="btn btn-success" type="submit" value=" {{ __('Submit') }}">
                </div> 

            </form>


        </div>
    </div>
@endsection
