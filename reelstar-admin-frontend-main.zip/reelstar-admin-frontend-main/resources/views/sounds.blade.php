@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/sounds.js') }}"></script>
@endsection

@section('content')
    <div class="text-right mb-3">

    </div>

 



    <div class="card">

        <div class="card-header">
            <h4>{{ __('Sounds') }}</h4>
          

            <a href="#" id="add-sound-cat" class="ml-auto btn btn-primary">{{ __('Add Sound Category') }}</a>
           

        

            <a href="#" id="add-sound" class="ml-2 btn btn-primary">{{ __('Add Sound') }}</a>

       

        </div>

        <div class="card-body">

            <ul class="nav nav-pills border-b mb-3  ml-0">

                <li role="presentation" class="nav-item"><a class="nav-link pointer active" href="#Section2" role="tab"
                        data-toggle="tab">{{ __('Sounds') }}
                        <span class="badge badge-transparent"></span></a>
                </li>

                <li role="presentation" class="nav-item"><a class="nav-link pointer " href="#Section1" aria-controls="home"
                        role="tab" data-toggle="tab">{{ __('Sound Categories') }}<span
                            class="badge badge-transparent total_open_complaint"></span></a>
                </li>


            </ul>

            <div class="tab-content tabs" id="home">
                {{-- Section 1 --}}
                <div role="tabpanel" class="tab-pane row" id="Section1">
                    <div class="table-responsive col-12">
                        <table class="table table-striped w-100" id="SoundCategoriesTable">
                            <thead>
                                <tr>
                                    <th>{{ __('Image') }}</th>
                                    <th>{{ __('Title') }}</th>
                                    <th>{{ __('Sound Count') }}</th>
                                    <th>{{ __('Action') }}</th> {{-- Edit and Delete --}}
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
                {{-- Section 2 --}}
                <div role="tabpanel" class="tab-pane row active" id="Section2">


                <div class="col-md-12">
        <div class="row input-daterange">

                <div class="col-md-4">
                    <label>Start Date</label>
                    <input type="date" name="from_date" id="from_date" class="form-control" placeholder="From Date"  />
                </div>
                <div class="col-md-4">
                <label>End Date</label>
                    <input type="date" name="to_date" id="to_date" class="form-control" placeholder="To Date"  />
                    <div class="col-sm-12 text-danger" id="error_log"></div>
                </div>
                <div class="col-md-4">
              
                    <button type="button" name="filter" id="filter" class="btn btn-primary">Filter</button>
                    <a href="{{ route('posts') }}"  name="refresh"  class="btn btn-warning">Clear</a>
                </div>
            </div>
</div>


                    <div class="table-responsive col-12">
                        <table class="table table-striped w-100" id="SoundsTable">
                            <thead>
                                <tr>
                                    <th>{{ __('Image') }}</th>
                                    <th>{{ __('Sound') }}</th>
                                    <th>{{ __('Title') }}</th>
                                    <th>{{ __('Category') }}</th>
                                    <th>{{ __('Duration') }}</th>
                                    <th>{{ __('Singer') }}</th>
                                    <th>{{ __('Video Count') }}</th>
                                    <th>{{ __('Created at') }}</th>
                                    <th>{{ __('Action') }}</th> {{-- Edit and Delete --}}
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Edit Sound Modal --}}
    <div class="modal fade" id="editSoundItem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <h4>{{ __('Edit Sound') }}</h4>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="" method="post" enctype="multipart/form-data" id="editSoundForm" autocomplete="off">
                        @csrf

                        <input type="hidden" class="form-control" id="editSoundId" name="id" value="">

                        <img height="60" width="60" class="rounded mb-1" id="sound-img-view" src=""
                            alt="">

                        {{-- Image --}}
                        <div class="form-group">
                            <div class="mb-3">
                                <label for="image" class="form-label">{{ __('Image') }}</label>
                                <input class="form-control" type="file" id="editImage" name="image"
                                    accept="image/png, image/gif, image/jpeg">
                            </div>
                        </div>

                        <audio id="view-sound" controls></audio>
                        {{-- Sound File --}}
                        <div class="form-group">
                            <div class="mb-3">
                                <label for="sound" class="form-label">{{ __('Sound File') }}</label>
                                <input class="form-control" type="file" id="editSound" name="sound"
                                    accept=".mp3,audio/*">
                            </div>
                        </div>

                        {{-- Title --}}
                        <div class="form-group">
                            <label> {{ __('Title') }}</label>
                            <input id="editSoundTitle" type="text" name="title" class="form-control" required>
                        </div>

                        {{-- Category --}}
                        <div class="form-group">
                            <label for="gender">{{ __('Category') }}</label>
                            <select name="sound_category_id" id="editSoundCatSelect" class="form-control form-control-sm"
                                aria-label="Default select example">

                                <option value=""></option>

                            </select>
                        </div>

                        <div class="form-row">
                            {{-- Duration --}}
                            <div class="form-group col-6">
                                <label> {{ __('Duration') }}</label>
                                <input id="editSoundDuration" type="text" name="duration" class="form-control"
                                    required>
                            </div>

                            {{-- Singer --}}
                            <div class="form-group col-6">
                                <label> {{ __('Singer') }}</label>
                                <input id="editSoundSinger" type="text" name="singer" class="form-control" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>
    {{-- Add Sound Modal --}}
    <div class="modal fade" id="addSoundItem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <h4>{{ __('Add Sound') }}</h4>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="" method="post" enctype="multipart/form-data" class="add_category"
                        id="addSoundForm" autocomplete="off">
                        @csrf

                        {{-- Image --}}
                        <div class="form-group">
                            <div class="mb-3">
                                <label for="image" class="form-label">{{ __('Image') }}</label>
                                <input class="form-control" type="file" id="image" name="image"
                                    accept="image/png, image/gif, image/jpeg" required>
                            </div>
                        </div>
                        {{-- Sound File --}}
                        <div class="form-group">
                            <div class="mb-3">
                                <label for="sound" class="form-label">{{ __('Sound File') }}</label>
                                <input class="form-control" type="file" id="sound" name="sound"
                                    accept=".mp3,audio/*" required>
                            </div>
                        </div>

                        {{-- Title --}}
                        <div class="form-group">
                            <label> {{ __('Title') }}</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>

                        {{-- Category --}}
                        <div class="form-group">
                            <label for="gender">{{ __('Category') }}</label>
                            <select name="sound_category_id" id="gender" class="form-control form-control-sm"
                                aria-label="Default select example">
                            
                                    <option value="">
                                    </option>
                            
                            </select>
                        </div>


                        {{-- Duration --}}
                        <div class="form-group">
                            <label> {{ __('Duration') }}</label>
                            <input type="text" name="duration" class="form-control" required>
                        </div>

                        {{-- Singer --}}
                        <div class="form-group">
                            <label> {{ __('Singer') }}</label>
                            <input type="text" name="singer" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    {{-- Add Sound Category Modal --}}
    <div class="modal fade" id="additem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <h4>{{ __('Add Sound Category') }}</h4>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="" method="post" enctype="multipart/form-data" class="add_category"
                        id="addForm" autocomplete="off">
                        @csrf
                        <div class="form-group">
                            <div class="mb-3">
                                <label for="sound_category_profile" class="form-label">{{ __('Image') }}</label>
                                <input class="form-control" type="file" id="sound_category_profile"
                                    name="sound_category_profile" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label> {{ __('Title') }}</label>
                            <input type="text" name="sound_category_name" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    {{-- Edit Sound Category Modal --}}
    <div class="modal fade" id="edititem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <h4>{{ __('Edit Sound Category') }}</h4>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="" method="post" enctype="multipart/form-data" class="add_category"
                        id="editForm" autocomplete="off">
                        @csrf

                        <input type="hidden" class="form-control" id="editId" name="id" value="">

                        <img height="150" width="150" class="rounded mb-3" id="sound-cat-img-view" src=""
                            alt="">

                        <div class="form-group">
                            <div class="mb-3">
                                <label for="sound_category_profile" class="form-label">{{ __('Image') }}</label>
                                <input class="form-control" type="file" id="edit_sound_category_profile"
                                    name="sound_category_profile">
                            </div>
                        </div>
                        <div class="form-group">
                            <label> {{ __('Title') }}</label>
                            <input id="edit_sound_category_name" type="text" name="sound_category_name"
                                class="form-control" required>
                        </div>

                        <div class="form-group">
                            <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    </div>
@endsection
