@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/coinpackages.js') }}"></script>
@endsection

@section('content')
<div class="card">
        <div class="card-header">
            <h4>{{ __('Coin Packages') }}</h4>
            <div class="text-right ml-auto">
           
                <a class="btn btn-primary addModalBtn" data-toggle="modal" data-target="#additem"
                    href="">{{ __('Add Coin Packages') }}
                </a>
            </div>
        </div>

        <div class="card-body row">
            <div class="table-responsive col-12">
                <table class="table table-striped w-100" id="table-222">
                    <thead>
                        <tr>
                            <th> {{ __('Package Name') }}</th>
                            <th> {{ __('Coin Amount') }}</th>
                            <th> {{ __('Action') }}</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>

        {{-- Add Modal --}}
        <div class="modal fade" id="additem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4>{{ __('Add Coin Packages') }}</h4>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form action="" method="post" enctype="multipart/form-data" class="" id="addForm"
                            autocomplete="off">
                            @csrf
                            <div class="form-group">
                                <label> {{ __('Package Name') }}</label>
                                <input type="text" autocomplete="off" placeholder="package name" name="package_name" maxlength="100" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label> {{ __('Package Amount') }}</label>
                                <input type="number" step=".01" autocomplete="off" placeholder="package amount" maxlength="100" name="package_amount" class="form-control"
                                    required>
                            </div>

                            <div class="form-group">
                                <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>

        {{-- Edit Modal --}}
        <div class="modal fade" id="edititem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4>{{ __('Edit Coin Package') }}</h4>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form action="" method="post" enctype="multipart/form-data" class="add_category" id="editForm"
                            autocomplete="off">
                            @csrf

                            <input type="hidden" class="form-control" id="editId" name="id" value="">

                            <div class="form-group">
                                <label> {{ __('Package Name') }}</label>
                                <input id="package_name" type="text" autocomplete="off" name="coin_package_name"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label> {{ __('Amount') }}</label>
                                <input id="coin_package_amount" type="number" step=".01" autocomplete="off" name="coin_package_amount"
                                    class="form-control" required>
                            </div>

                            <div class="form-group">
                                <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>
@endsection