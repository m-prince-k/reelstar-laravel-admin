@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/viewCampaign.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('asset/style/createads.css') }}">
@endsection

@section('content')
    <div class="card">
        <div class="card-header">
            <h4>
                {{ __('View Campaign :') }}
            </h4>
            <h4>
                {{ $ad->ads_number ?? '' }}
            </h4>

            {{-- Views --}}
            <h4 class="ml-auto">
                {{ __('Views :') }}
            </h4>
            <h4>
                {{ __($ad->views ?? '') }}
            </h4>
            {{-- Clicks --}}
            <h4 class="ml-2">
                {{ __('Clicks :') }}
            </h4>
            <h4>
                {{ __($ad->clicks ?? '') }}
            </h4>
            {{-- CTR --}}
            <h4 class="ml-2">
                {{ __('CTR :') }}
            </h4>
            <h4>
                {{ __($ad->ctr ?? '') }}
            </h4>

        </div>

        <div class="card-body">
            <form action="" method="post" enctype="multipart/form-data" id="editCampaignForm" autocomplete="off">
                @csrf

                <input type="hidden" class="form-control" id="itemId" name="id" value="{{ $ad->custom_ads_id ?? '' }}">

                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label>{{ __('Campaign Title (For Reference Only)') }}</label>
                        <input id="ads_title" name="ads_title" class="form-control" value="{{ $ad->ads_title }}" required
                            disabled>
                    </div>
                </div>

                <div class="form-row ">
                    <div class="form-group col-md-6">
                        <label>{{ __('Brand Name') }}</label>
                        <input id="brand_name" name="brand_name" class="form-control" value="{{ $ad->brand_name }}"
                            required disabled>
                    </div>
                    <div class="form-group col-md-6">
                        <label>{{ __('Headline') }}</label>
                        <input id="headline" name="headline" class="form-control" value="{{ $ad->headline }}" required
                            disabled>
                    </div>
                </div>

                <div class="form-row ">
                    <div class="form-group col-md-6">
                        <label>{{ __('Description') }}</label>
                        <textarea disabled id="description" name="description" class="form-control" required>{{ $ad->description }}</textarea>
                    </div>
                    <div class="form-group col-md-6 ">
                        <img height="65" width="65" class="rounded mt-4" id="brand_logo_img"
                            src="{{ env('ITEM_BASE_URL') . $ad->brand_logo }}" alt="">

                        {{-- <div class="form-group col-md-6 mt-3">
                            <label for="brand_logo" class="form-label">{{ __('Brand Logo') }}</label>
                            <input class="form-control" type="file" id="brand_logo" name="brand_logo"
                                accept="image/png, image/gif, image/jpeg">
                        </div> --}}

                    </div>
                </div>
                <div class="form-row ">
                    <div class="form-group col-md-4">
                        <label>{{ __('Button Text') }}</label>
                        <input value="{{ $ad->button_text }}" name="button_text" class="form-control" value=""
                            required disabled>
                    </div>
                    <div class="form-group col-md-4">
                        <label>{{ __('Button Color') }}</label>
                        <input type="color" name="button_color" class="form-control" value="{{ $ad->button_color }}"
                            required disabled>
                    </div>
                    <div class="form-group col-md-4">
                        <label>{{ __('End Date') }}</label>
                        <input min="<?php echo date('Y-m-d'); ?>" id="end_date" type="date" name="end_date" class="form-control"
                            value="{{ $ad->end_date }}" required disabled>
                    </div>
                </div>

                <div class="form-row mx-xl-1 ">
                    {{-- Android Link --}}
                    <div class="form-row bg-link mr-xl-1  col-xl">
                        <div class="form-group col-md-2">
                            <label class="d-block" for="">{{ __('For Android') }}</label>
                            <label class="switch ">
                                <input type="checkbox" name="is_android" id="androidSwitch"
                                    {{ $ad->is_android == 1 ? 'checked' : '' }} disabled>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="form-group col-md-10">
                            <label>{{ __('Android Link') }}</label>
                            <input id="android_link" type="text" name="android_link" class="form-control"
                                value="{{ $ad->android_link }}" disabled>
                        </div>
                    </div>

                    {{-- iOS Link --}}
                    <div class="form-row bg-link ml-xl-1 mt-2 mt-xl-0 col-xl">
                        <div class="form-group col-md-2">
                            <label class="d-block" for="">{{ __('For iOS') }}</label>
                            <label class="switch ">
                                <input type="checkbox" name="is_ios" id="iosSwitch"
                                    {{ $ad->is_ios == 1 ? 'checked' : '' }} disabled>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="form-group col-md-10">
                            <label>{{ __('iOS Link') }}</label>
                            <input id="ios_link" name="ios_link" class="form-control" value="{{ $ad->ios_link }}"
                                disabled>
                        </div>
                    </div>
                </div>

                {{-- Images and video Preview --}}
                <div class="form-row">
                    {{-- Horizintal Image --}}
                    <div class="form-group col-md-4">
                        <img height="120" width="120" class="rounded mt-4" id="horizontal_image_img"
                            src="{{ env('ITEM_BASE_URL') . $ad->horizontal_image }}" alt="">
                    </div>
                    {{-- Vertical Image --}}
                    <div class="form-group col-md-4">
                        <img height="120" width="120" class="rounded mt-4" id="vertical_image_img"
                            src="{{ env('ITEM_BASE_URL') . $ad->vertical_image }}" alt="">
                    </div>
                    {{-- Video --}}
                    @if ($ad->video != null)
                        <div class="form-group col-md-4 mt-4">
                            <button id="btn_play" rel=" {{ env('ITEM_BASE_URL') . $ad->video }}"
                                class="btn btn-lg btn-info">{{ __('Play Video') }}</button>
                        </div>
                    @endif

                </div>
                {{-- Images and video --}}
                <div class="form-row ">
                    {{-- Horizintal Image --}}
                    <div class="form-group col-md-4">
                        <label for="horizontal_image" class="form-label">{{ __('Horizontal Image') }}</label>
                        {{-- <input class="form-control" type="file" id="horizontal_image" name="horizontal_image"
                            accept="image/png, image/gif, image/jpeg"> --}}
                    </div>
                    {{-- Vertical Image --}}
                    <div class="form-group col-md-4">
                        <label for="vertical_image" class="form-label">{{ __('Vertical Image') }}</label>
                        {{-- <input class="form-control" type="file" id="vertical_image" name="vertical_image"
                            accept="image/png, image/gif, image/jpeg"> --}}
                    </div>
                    {{-- Video --}}
                    <div class="form-group col-md-4">
                        <label for="video" class="form-label">{{ __('Video') }}</label>
                        {{-- <input class="form-control" type="file" id="video" name="video"
                            accept="video/mp4,video/x-m4v,video/*"> --}}
                    </div>
                </div>

                <div class="form-group d-flex justify-content-end">
                    <button id="btn_cancel" class="btn btn-danger  mr-2">{{ __('Cancel') }}</button>
                    {{-- <input class="btn btn-success" type="submit" value=" {{ __('Submit') }}"> --}}
                </div>

            </form>


        </div>
    </div>

    {{-- Video Modal --}}
    <div class="modal fade" id="video_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>{{ __('View Content') }}</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="videoDesc"></p>
                    <video rel="" id="advideo" width="450" height="450" controls>
                        <source src="{{ env('ITEM_BASE_URL') . $ad->video }}" type="video/mp4">
                    </video>
                </div>

            </div>
        </div>
    </div>
@endsection
