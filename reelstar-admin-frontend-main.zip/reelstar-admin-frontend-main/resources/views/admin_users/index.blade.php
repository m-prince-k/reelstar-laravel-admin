@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/admin_user.js') }}"></script>
@endsection


<?php    

        use App\Models\Admin;         
        $check_permission = Admin::checkPermissionToLoggedUser('adminuser-create');
             
?>


@section('content')

    <div class="text-right mb-3">

    </div>

    <div class="card">

        <div class="card-header">
            <h4>{{ __('Admin Users') }}</h4>

            @if($check_permission)
            <a href="{{ route('adminUsers.create') }}" id="create_role"
                class="ml-auto btn btn-primary">{{ __('Create New User') }}</a>
                @endif
        </div>

        <div class="card-body">

            <ul class="nav nav-pills border-b mb-3  ml-0">

                <li role="presentation" class="nav-item"><a class="nav-link pointer active" href="#Section1"
                        aria-controls="home" role="tab" data-toggle="tab">{{ __('All Admin Users') }}<span
                            class="badge badge-transparent total_open_complaint"></span></a>
                </li>

            </ul>

            <div class="col-md-12">
        <div class="row input-daterange">

                <div class="col-md-4">
                    <label>Start Date</label>
                    <input type="date" name="from_date" id="from_date" class="form-control" placeholder="From Date"  />
                </div>
                <div class="col-md-4">
                <label>End Date</label>
                    <input type="date" name="to_date" id="to_date" class="form-control" placeholder="To Date"  />
                    <div class="col-sm-12 text-danger" id="error_log"></div>
                </div>
                <div class="col-md-4">
              
                    <button type="button" name="filter" id="filter" class="btn btn-primary">Filter</button>
                    <a href="{{ route('posts') }}"  name="refresh"  class="btn btn-warning">Clear</a>
                </div>
            </div>
</div>

            <div class="tab-content tabs" id="home">
                {{-- Section 1 --}}
                <div role="tabpanel" class="row tab-pane active" id="Section1">
                    <div class="table-responsive col-12">
                        <table class="table table-striped w-100" id="AdminUsersTable">
                            <thead>
                                <tr>
                                    <th>{{ __('Username') }}</th>
                                    <th>{{ __('Role') }}</th>
                                    <th>{{ __('Created At') }}</th>
                                    <th>{{ __('Action') }}</th> 
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
        </div>
    </div>

    </div>
@endsection
