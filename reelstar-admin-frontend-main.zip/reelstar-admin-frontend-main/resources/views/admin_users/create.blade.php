@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/admin_user.js') }}"></script>
@endsection



@section('content')
 

    <div class="card">
        <div class="card-header">
            <h4>
			Create New Admin User 
            </h4>

        </div>

        <div class="card-body">
            <form action="{{ route('adminUsers.store') }}" method="post" enctype="multipart/form-data" id="CreateAdminUserForm" autocomplete="off">
                @csrf

              
				<div class="form-row">
				<div class="form-group col-md-12">
										<label for="exchange_category" class="required">Role</label>
										<!-- multiple="multiple" -->
										<select name="role_code" id="role_code" class="form-control form-control-sm"
                                aria-label="Default select example" >
											@foreach ($roles as $role)
												<option value="{{ $role->name }}">{{ $role->code }}</option>
											@endforeach
										</select>
										@error('role_code')
											<span class="text-danger">{{ $message }}</span>
										@enderror
									</div>
									</div>

									<div class="form-row">
                    <div class="form-group col-md-12">
                        <label>{{ __('Username') }}</label>
                        <input  type="text"  name="username" id="username" class="form-control @error('username') form-control-error @enderror" placeholder="Enter Username" value="{{ old('username') }}" required>
						@error('username')
										<span class="text-danger">{{ $message }}</span>
									@enderror
					</div>
                </div>



				<div class="form-row">
                    <div class="form-group col-md-12">
                        <label>{{ __('Password') }}</label>
                        <input  type="password"  name="password" id="password" class="form-control @error('password') form-control-error @enderror" placeholder="Enter Password" value="{{ old('password') }}" required>
						@error('password')
										<span class="text-danger">{{ $message }}</span>
									@enderror
					</div>
                </div>



				<div class="form-row">
                    <div class="form-group col-md-12">
                        <label>{{ __('Confirm Password') }}</label>
                        <input  type="password"  name="confirm-password" id="password-confirm" class="form-control @error('confirm-password') form-control-error @enderror" placeholder="Enter Confirm Password" value="{{ old('confirm-password') }}" required>
						@error('confirm-password')
										<span class="text-danger">{{ $message }}</span>
									@enderror
					</div>
                </div>



                <div class="form-group d-flex justify-content-end">
                    <button id="btn_cancel" class="btn btn-danger  mr-2">{{ __('Cancel') }}</button>
                    <input class="btn btn-success" type="submit" value=" {{ __('Submit') }}">
                </div>

            </form>


        </div>
    </div>
@endsection



@push('scripts')
<script>
	$("#checkPermissionAll").click(function(){
		if($(this).is(':checked'))
		{
			$('input[type=checkbox]').prop('checked', true)
		}else
		{
			$('input[type=checkbox]').prop('checked', false)
		}
	})
</script>
@endpush