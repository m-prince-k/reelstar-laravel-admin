@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/roles.js') }}"></script>
@endsection



@section('content')
 

    <div class="card">
        <div class="card-header">
            <h4>
			Edit Admin User Information ({{ $admin_user->username }})
            </h4>

        </div>

        <div class="card-body">
            <form action="{{ route('adminUsers.update', $admin_user->user_id) }}" method="post" enctype="multipart/form-data" id="EditAdminUserForm" autocomplete="off">
                @csrf



				<div class="form-row">
				<div class="form-group col-md-12">
										<label for="exchange_category" class="required">Role</label>
										<!-- multiple="multiple" -->
										<select name="role_code" id="role_code" class="form-control form-control-sm"
                                aria-label="Default select example" >
											@foreach ($roles as $role)
												<option value="{{ $role->name }}"   {{ $admin_user->hasRole($role->name) ? 'selected' : '' }} >{{ $role->code }}</option>
											@endforeach
										</select>
										@error('role_code')
											<span class="text-danger">{{ $message }}</span>
										@enderror
									</div>
									</div>




                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label>{{ __('Username') }}</label>
                        <input  type="text"  name="username" id="username" class="form-control @error('username') form-control-error @enderror" placeholder="Enter Username" value="{{ $admin_user->username }}" required>
						@error('username')
										<span class="text-danger">{{ $message }}</span>
									@enderror
					</div>
                </div>
				

			
			


            

                <div class="form-group d-flex justify-content-end">
                    <button id="btn_cancel" class="btn btn-danger  mr-2">{{ __('Cancel') }}</button>
                    <input class="btn btn-success" type="submit" value=" {{ __('Submit') }}">
                </div>

            </form>


        </div>
    </div>
@endsection


@push('scripts')
<script>
	$("#checkPermissionAll").click(function(){
		if($(this).is(':checked'))
		{
			$('input[type=checkbox]').prop('checked', true)
		}else
		{
			$('input[type=checkbox]').prop('checked', false)
		}
	})
</script>
@endpush