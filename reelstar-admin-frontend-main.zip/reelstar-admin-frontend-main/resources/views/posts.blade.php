@extends('include.app')
@section('header')

    <script src="{{ asset('asset/script/posts.js') }}"></script>

@endsection

@section('content')
    <div class="text-right mb-3">

    </div>

    <div class="card">

        <div class="card-header">
            <h4>{{ __('Posts') }}</h4>
        </div>
               
        <div class="col-md-12">
        <div class="row input-daterange">

                <div class="col-md-4">
                    <label>Start Date</label>
                    <input type="date" name="from_date" id="from_date" class="form-control" placeholder="From Date"  />
                </div>
                <div class="col-md-4">
                <label>End Date</label>
                    <input type="date" name="to_date" id="to_date" class="form-control" placeholder="To Date"  />
                    <div class="col-sm-12 text-danger" id="error_log"></div>
                </div>
                <div class="col-md-4">
              
                    <button type="button" name="filter" id="filter" class="btn btn-primary">Filter</button>
                    <a href="{{ route('posts') }}"  name="refresh"  class="btn btn-warning">Clear</a>
                </div>
            </div>
</div>
         

        <div class="card-body row">


 
            <div class="table-responsive col-12">
                <table class="table table-striped w-100" id="PostsTable">
                    <thead>
                        <tr>
                            <th>{{ __('Content') }}</th>
                            <th>{{ __('Thumbnail') }}</th>
                            <th>{{ __('Identity') }}</th>
                            <th>{{ __('Fullname') }}</th>
                            <th>{{ __('Description') }}</th>
                            <th>{{ __('Views') }}</th>
                            <th>{{ __('Likes') }}</th>
							 <th>{{ __('Video ID') }}</th>
                            <th>{{ __('Created at') }}</th>
                            <th>{{ __('Action') }}</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>


        </div>
    </div>

    {{-- Video Modal --}}
    <div class="modal fade" id="video_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>{{ __('View Content') }}</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="videoDesc"></p>
                    <video rel="" id="video" width="450" height="450" controls>
                        <source src="" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>

            </div>
        </div>
    </div>

    </div>


 
@endsection
