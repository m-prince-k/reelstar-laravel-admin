@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/users.js') }}"></script>
@endsection

@section('content')
    <div class="text-right mb-3">

    </div>

    <div class="card">

        <div class="card-header">
            <h4>{{ __('Users') }}</h4>
        </div>


        <div class="col-md-12">
        <div class="row input-daterange">

                <div class="col-md-4">
                    <label>Start Date</label>
                    <input type="date" name="from_date" id="from_date" class="form-control" placeholder="From Date"  />
                </div>
                <div class="col-md-4">
                <label>End Date</label>
                    <input type="date" name="to_date" id="to_date" class="form-control" placeholder="To Date"  />
                    <div class="col-sm-12 text-danger" id="error_log"></div>
                </div>
                <div class="col-md-4">
              
                    <button type="button" name="filter" id="filter" class="btn btn-primary">Filter</button>
                    <a href="{{ route('users') }}"  name="refresh"  class="btn btn-warning">Clear</a>
                </div>
            </div>
</div>


        <div class="card-body">

            <ul class="nav nav-pills border-b mb-3  ml-0">

                <!-- <li role="presentation" class="nav-item"><a class="nav-link pointer active" href="#Section1"
                        aria-controls="home" role="tab" data-toggle="tab">{{ __('All Users') }}<span
                            class="badge badge-transparent total_open_complaint"></span></a>
                </li> -->

                {{-- <li role="presentation" class="nav-item"><a class="nav-link pointer" href="#Section2" role="tab"
                            data-toggle="tab">{{ __("Fake Users") }}
                            <span class="badge badge-transparent total_close_complaint"></span></a>
                    </li> --}}

            </ul>

            <div class="tab-content tabs" id="home">
                {{-- Section 1 --}}
                <div role="tabpanel" class="row tab-pane active" id="Section1">
                    <div class="table-responsive col-12">
                        <table class="table table-striped w-100" id="UsersTable">
                            <thead>
                                <tr>
                                    <th>{{ __('User Image') }}</th>
                                    <th>{{ __('Full Name') }}</th>
                                    <th>{{ __('Identity') }}</th>
                                    <th>{{ __('Username') }}</th>
                                    <th>{{ __('Refferal By') }}</th>
                                    <th>{{ __('Refferal Code') }}</th>
                                    <th>{{ __('Refferal Count') }}</th>
                                    <th>{{ __('Created At') }}</th>
                                    <th>{{ __('Action') }}</th> {{-- View and Block --}}
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
                {{-- Section 2 --}}
                <div role="tabpanel" class="tab-pane" id="Section2">
                    <div class="table-responsive">
                        <table class="table table-striped w-100" id="FakeUsersTable">
                            <thead>
                              
                          
                                <tr>
                                    <th>{{ __('Full Name') }}</th>
                                    <th>{{ __('Identity') }}</th>
                                    <th>{{ __('Username') }}</th>
                                    <th>{{ __('Refferal By') }}</th>
                                    <th>{{ __('Refferal Code') }}</th>
                                    <th>{{ __('Refferal Count') }}</th>
                                    <th>{{ __('Action') }}</th>
                                </tr>    
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
@endsection
