@extends('include.app')
@section('header')
    <script src="{{ asset('asset/script/coinPlans.js') }}"></script>
@endsection

@section('content')
    <div class="card">
        <div class="card-header">
            <h4>{{ __('Coin Plans') }}</h4>
            <div class="text-right ml-auto">

           
                <a class="btn btn-primary addModalBtn" data-toggle="modal" data-target="#additem"
                    href="">{{ __('Add Coin Plan') }}
                </a>
            </div>
        </div>

        <div class="card-body row">
            <div class="table-responsive col-12">
                <table class="table table-striped w-100" id="table-22">
                    <thead>
                        <tr>
                            <th> {{ __('Coin Amount') }}</th>
                            <th> {{ __('Price') }}</th>
                            <th> {{ __('Android Product ID') }}</th>
                            <th> {{ __('iOS Product ID') }}</th>
                            <th> {{ __('Action') }}</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>

        {{-- Add Modal --}}
        <div class="modal fade" id="additem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4>{{ __('Add Coin Plan') }}</h4>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form action="" method="post" enctype="multipart/form-data" class="" id="addForm"
                            autocomplete="off">
                            @csrf
                        <input type="hidden" id="coin_val" value="{{$coin_value}}" />
                            <div class="form-group">
                                <label> {{ __('Coin Amount') }}</label>
                                <input type="number" autocomplete="off" id="coin_amount_keyup" placeholder="coin amount" name="coin_amount" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label> {{ __('Price') }}</label>
                                <input type="number" step=".01" readonly id="coin_price" autocomplete="off" placeholder="coin price" name="price" class="form-control"
                                    required>
                            </div>
                            <div class="form-group">
                                <label> {{ __('Android Product ID') }}</label>
                                <input type="text" name="playstore_product_id" placeholder="android product id" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label> {{ __('iOS Product ID') }}</label>
                                <input type="text" name="appstore_product_id" placeholder="ios product id" class="form-control" required>
                            </div>


                            <div class="form-group">
                                <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>

        {{-- Edit Modal --}}
        <div class="modal fade" id="edititem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4>{{ __('Edit Coin Plan') }}</h4>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form action="" method="post" enctype="multipart/form-data" class="add_category" id="editForm"
                            autocomplete="off">
                            @csrf

                            <input type="hidden" class="form-control" id="editId" name="id" value="">

                            <div class="form-group">
                                <label> {{ __('Coin Amount') }}</label>
                                <input id="edit_coin_amount" type="number" autocomplete="off" name="coin_amount"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label> {{ __('Price') }}</label>
                                <input id="edit_price" type="number" readonly  step=".01" autocomplete="off" name="price"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label> {{ __('Android Product ID') }}</label>
                                <input id="edit_android_product_id" type="text" name="playstore_product_id"
                                    class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label> {{ __('iOS Product ID') }}</label>
                                <input id="edit_ios_product_id" type="text" name="appstore_product_id"
                                    class="form-control" required>
                            </div>

                            <div class="form-group">
                                <input class="btn btn-primary mr-1" type="submit" value=" {{ __('Submit') }}">
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>
        <script>
            $("#coin_amount_keyup,#edit_coin_amount").on("keyup",function(){
                let ownValue= $(this).val();
                let coin_val=$("#coin_val").val();
                let totalPrice=(parseFloat(ownValue) * parseFloat(coin_val));
                $("#coin_price").val(totalPrice)
                $("#edit_price").val(totalPrice)
            })
        </script>
    @endsection
