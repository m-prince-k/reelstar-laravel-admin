<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\SoundController;
use App\Http\Controllers\PagesController;
use App\Http\Controllers\CustomAdsController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/clear', function () {
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('config:clear');
    $exitCode = Artisan::call('route:clear');
    $exitCode = Artisan::call('view:clear');

    $data = ['msg' => 'success', 'message' => 'Cache Cleared and Optimized!'];


    dd($data);

})->name('clear.cache');


Route::get('/', [LoginController::class, 'login'])->middleware(["CheckAdmin"])->name('/');

Route::post('login', [LoginController::class, 'checklogin'])->name('login');

Route::get('index', [LoginController::class, 'index'])->middleware(["checkLogin"])->name("index");

Route::get('logout', [LoginController::class, 'logout'])->middleware(['checkLogin'])->name('logout');

Route::get("blockUnBlockUser/{id}",[UsersController::class, 'blockUnBlockUser'])->middleware(['checkLogin'])->name("blockUnBlockUser");

Route::get('users', [UsersController::class, 'users'])->middleware(['checkLogin'])->name("users");

Route::get('viewUserDetails/{id}', [UsersController::class, 'viewUserDetails'])->middleware(['checkLogin'])->name("viewUserDetails");

Route::get('verifyUserFromAdmin/{id}', [PostController::class, 'verifyUserFromAdmin'])->middleware(['checkLogin'])->name('verifyUserFromAdmin');

Route::get("enabledDisabledAdmin/{id}",[PostController::class, 'enabledDisabledAdmin'])->middleware(['checkLogin'])->name('enabledDisabledAdmin');

Route::get("sponsorEnabled/{id}",[PostController::class, 'sponsorEnabled'])->middleware(['checkLogin'])->name('sponsorEnabled');

Route::post('fetchAllUsersList', [UsersController::class, 'fetchAllUsersList'])->middleware(['checkLogin'])->name('fetchAllUsersList');

Route::post('fetchUserPostList', [PostController::class, 'fetchUserPostList'])->middleware(['checkLogin'])->name('fetchUserPostList');


Route::post('editUserFromAdmin', [UsersController::class, 'editUserFromAdmin'])->middleware(['checkLogin'])->name('editUserFromAdmin');
//




Route::get('posts', [PostController::class, 'showposts'])->middleware(['checkLogin'])->name("posts");

Route::post('deletePost', [PostController::class, 'deletePost'])->middleware(['checkLogin'])->name('deletePost');

Route::post('deletePostByUserId', [PostController::class, 'deletePostByUserId'])->middleware(['checkLogin'])->name('deletePostByUserId');

Route::post('fetchAllPostsList', [PostController::class, 'fetchAllPostsList'])->middleware(['checkLogin'])->name('fetchAllPostsList');


Route::get('sounds', [SoundController::class, 'showSounds'])->middleware(['checkLogin'])->name("sounds");


Route::get('deleteAdminNotification/{id}', [SettingsController::class, 'deleteAdminNotification'])->middleware(['checkLogin'])->name('deleteAdminNotification');

Route::get('getAdminNotificationById/{id}', [SettingsController::class, 'getAdminNotificationById'])->middleware(['checkLogin'])->name('getAdminNotificationById');

Route::post('editAdminNotification', [SettingsController::class, 'editAdminNotification'])->middleware(['checkLogin'])->name('editAdminNotification');

//
Route::post('getAllUsers', [UsersController::class, 'getAllUsers'])->middleware(['checkLogin'])->name('getAllUsers');

Route::get('notification', [SettingsController::class, 'notification'])->middleware(['checkLogin'])->name('notification');

Route::post('addAdminNotification', [SettingsController::class, 'addAdminNotification'])->middleware(['checkLogin'])->name('addAdminNotification');
//

Route::post('fetchAdminNotificationsList', [SettingsController::class, 'fetchAdminNotificationsList'])->middleware(['checkLogin'])->name('fetchAdminNotificationsList');

Route::post('updatePrivacy', [PagesController::class, 'updatePrivacy'])->middleware(['checkLogin'])->name('updatePrivacy');

Route::post('updateTerms', [PagesController::class, 'updateTerms'])->middleware(['checkLogin'])->name('updateTerms');
//




Route::get('viewPrivacy', [PagesController::class, 'viewPrivacy'])->middleware(['checkLogin'])->name('viewPrivacy');
Route::get('viewTerms', [PagesController::class, 'viewTerms'])->middleware(['checkLogin'])->name('viewTerms');
Route::get('getCoinPlanById/{id}', [SettingsController::class, 'getCoinPlanById'])->middleware(['checkLogin'])->name('getCoinPlanById');


Route::post('fetchCoinPlansList', [SettingsController::class, 'fetchCoinPlansList'])->middleware(['checkLogin'])->name('fetchCoinPlansList');
Route::get('deleteCoinPlan/{id}', [SettingsController::class, 'deleteCoinPlan'])->middleware(['checkLogin'])->name('deleteCoinPlan');
Route::post('editCoinPlan', [SettingsController::class, 'editCoinPlan'])->middleware(['checkLogin'])->name('editCoinPlan');
Route::post('addNewCoinPlan', [SettingsController::class, 'addNewCoinPlan'])->middleware(['checkLogin'])->name('addNewCoinPlan');

// -----------------------------------------------------coin packages start here-----------------------------------------------------------
Route::get('coinPackages', [SettingsController::class, 'coinPackages'])->middleware(['checkLogin'])->name('coinPackages');
Route::post('fetchCoinPackages', [SettingsController::class, 'fetchCoinPackages'])->middleware(['checkLogin'])->name('fetchCoinPackages');
Route::get('deleteCoinPackage/{id}', [SettingsController::class, 'deleteCoinPackage'])->middleware(['checkLogin'])->name('deleteCoinPackage');
//
Route::get('/getCoinPackagesById/{id}', [SettingsController::class, 'getCoinPackagesById'])->middleware(['checkLogin'])->name('getCoinPackagesById');

Route::post('editCoinPackages', [SettingsController::class, 'editCoinPackages'])->middleware(['checkLogin'])->name('editCoinPackages');

Route::post('addNewCoinPackages', [SettingsController::class, 'addNewCoinPackages'])->middleware(['checkLogin'])->name('addNewCoinPackages');
//------------------------------------------------------end of coin packages is here-------------------------------------------------------


// --------------------------------------------------------Custom ads start here---------------------------------------------------------
Route::get('customAds', [CustomAdsController::class, 'customAds'])->middleware(['checkLogin'])->name('customAds');

Route::get('createCustomAd', [CustomAdsController::class, 'createCustomAd'])->middleware(['checkLogin'])->name('createCustomAd');

Route::post('createNewAd', [CustomAdsController::class, 'createNewAd'])->middleware(['checkLogin'])->name('createNewAd');

Route::post('fetchAdsList', [CustomAdsController::class, 'fetchAdsList'])->middleware(['checkLogin'])->name('fetchAdsList');

Route::get('editAd/{id}', [CustomAdsController::class, 'editAd'])->middleware(['checkLogin'])->name('editAd');

//
// --------------------------------------------------------end of custom ads is here-----------------------------------------------------

Route::get('viewCampaign/{id}', [CustomAdsController::class, 'viewAd'])->middleware(['checkLogin'])->name('viewCampaign');


Route::get('deleteAd/{id}', [CustomAdsController::class, 'deleteAd'])->middleware(['checkLogin'])->name('deleteAd');
Route::get('getAdById/{id}', [CustomAdsController::class, 'getAdById'])->middleware(['checkLogin'])->name('getAdById');
Route::post('editAdFromAdmin', [CustomAdsController::class, 'editAdFromAdmin'])->middleware(['checkLogin'])->name('editAdFromAdmin');
Route::get('editAd/{id}', [CustomAdsController::class, 'editAd'])->middleware(['checkLogin'])->name('editAd');
Route::post('editAdFromAdmin', [CustomAdsController::class, 'editAdFromAdmin'])->middleware(['checkLogin'])->name('editAdFromAdmin');
Route::get('changeAdStatus/{id}/{status}', [CustomAdsController::class, 'changeAdStatus'])->middleware(['checkLogin'])->name('changeAdStatus');

// ----------------------------------------------------------transfer approval is start here---------------------------------------------

Route::get('redeemRequests', [SettingsController::class, 'redeemRequests'])->middleware(['checkLogin'])->name('redeemRequests');
Route::post('fetchRedeemRequestsList', [SettingsController::class, 'fetchRedeemRequestsList'])->middleware(['checkLogin'])->name('fetchRedeemRequestsList');
Route::get('completeRedeemRequest/{id}', [SettingsController::class, 'completeRedeemRequest'])->middleware(['checkLogin'])->name('completeRedeemRequest');
Route::get('rejectRedeemRequest/{id}', [SettingsController::class, 'rejectRedeemRequest'])->middleware(['checkLogin'])->name('rejectRedeemRequest');
// ----------------------------------------------------------end of transfeer approval is here-------------------------------------------





Route::get('coinPlans', [SettingsController::class, 'coinPlans'])->middleware(['checkLogin'])->name('coinPlans');

Route::get('viewSettings', [SettingsController::class, 'viewSettings'])->middleware(['checkLogin'])->name('viewSettings');

Route::post("updateGlobalSettings",[SettingsController::class, 'updateGlobalSettings'])->middleware(['checkLogin'])->name('updateGlobalSettings');


Route::get('changeShowAdsStatus/{id}', [SettingsController::class, 'changeShowAdsStatus'])->middleware(['checkLogin'])->name('changeShowAdsStatus');

// Route::get('/', function () {
//     return view('welcome');
// });
