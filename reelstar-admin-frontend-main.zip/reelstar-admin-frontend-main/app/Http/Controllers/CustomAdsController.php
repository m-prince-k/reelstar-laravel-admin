<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomAdsController extends Controller
{
    function customAds(Request $request){
        try {
            //code...
            return view('customAds');
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function createCustomAd(){
        try {
            //code...
            return view('createCustomAd');
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function fetchAdsList(Request $request) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $response="";
            if($request->input('search.value')){
                $payload = [
                    "search" =>$request->input('search.value')
                ];
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_MOBILE_BASE_URL')."fetchCustomAds",$payload);
            } else {
                $payload = [
                    //3 would be for fetching all custom ads
                    "is_device" =>"3"
                ];
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_MOBILE_BASE_URL')."fetchCustomAds",$payload);
            }

            $resultt=json_decode($response);
            $result = $resultt->data;

            $data = array();
            foreach ($result as $item) {
    
                // Status
                $status = "";
                if ($item->status == 0) {
                    $status = '  <label class="switch ">
                                    <input rel=' . $item->custom_ads_id . '  type="checkbox" class="ad_status">
                                    <span class="slider round"></span>
                                </label>';
                } else {
                    $status =
                        '  <label class="switch ">
                                    <input rel=' . $item->custom_ads_id . '  type="checkbox" class="ad_status" checked>
                                    <span class="slider round"></span>
                                </label>';
                }
    
    
                // Platform
                $platform = "";
                $android = '  <span  class="badge bg-success text-white badge-shadow ">' . __("ANDROID") . '</span>';
                $ios = '  <span  class="badge bg-dark text-white badge-shadow ">' . __("iOS") . '</span>';
    
                if ($item->is_android == 1) {
                    $platform = $android;
                }
                if ($item->is_ios == 1) {
                    $platform = $ios;
                }
                if ($item->is_android == 1 && $item->is_ios == 1) {
                    $platform = $android . $ios;
                }
    
    
                $delete = '<a href=""class=" btn btn-danger text-white delete ml-2" rel=' . $item->custom_ads_id . ' >' . __("Delete") . '</a>';
                $edit = '<a href="' . route('editAd', $item->custom_ads_id) . '" class=" btn btn-info text-white edit ml-2"    rel=' . $item->custom_ads_id . ' >' . __("Edit") . '</a>';
                $view = '<a href="' . route('viewCampaign', $item->custom_ads_id) . '" class=" btn btn-success text-white edit "    rel=' . $item->custom_ads_id . ' >' . __("View") . '</a>';
    
    
             
    
                // if(!$check_permission1)
                // {
                //     $edit =''; 
                // }
    
                // $check_permission11 = Admin::checkPermissionToLoggedUser('Custom-Ad-delete');
    
                // if(!$check_permission11)
                // {
                //     $delete =''; 
                // }

                $action = $view . $edit . $delete;
    
                $data[] = array(
                    isset($item->ads_number) ? $item->ads_number : 'N/A',
                    isset($item->ads_title) ? $item->ads_title :'N/A',
                    isset($item->brand_name) ? $item->brand_name : 'N/A',
                    isset($item->views) ? $item->views : 'N/A',
                    isset($item->clicks) ? $item->clicks : 'N/A',
                    isset($status) ? $status : 'N/A',
                    isset($platform) ? $platform : 'N/A',
                    isset($item->end_date) ? $item->end_date : 'N/A',
                    isset($item->created_at) ? $item->created_at : 'N/A',
                    $action,
                );
            }
            $json_data = array(
                "draw"            => intval($request->input('draw')),
                "recordsTotal"    => isset($totalData) ? intval($totalData) : '',
                "recordsFiltered" => isset($totalFiltered) ? $totalFiltered : '',
                "data"            => $data
            );
            echo json_encode($json_data);
            exit();

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function deleteAd($id) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                "custom_ads_id" => $id,
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."deleteCustomAds",$payload);
            $result = json_decode($response);
            return $result;
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function getAdById($id) {
        try {
            //code...
         
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function editAdFromAdmin(Request $request) {
        try {
            //code...
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function editAd($id) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                "custom_ads_id" => $id,
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."fetchAutoPopulateAds",$payload);
            $resultt = json_decode($response);
            $data = $resultt->data;
            return view('editAd',['ad' => $data]);
        } catch (\Throwable $th) {
            throw $th;
        }
    }

 
    function changeAdStatus($id, $status){
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                "custom_ads_id" => $id,
                "status" => $status
            ];
           

            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."changeAdStatus",$payload);
           $result = json_decode($response);
            return $result;
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function viewAd($id) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                "custom_ads_id" => $id,
            ];
           

            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."viewCustomAd",$payload);
            $result = json_decode($response);
            $ad=$result->data;
            return view("viewAd",['ad' => $ad]);
        } catch (\Throwable $th) {
            throw $th;
        }
    }
}
