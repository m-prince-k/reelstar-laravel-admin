<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;

class LoginController extends Controller
{
    function login()
{
        return view('login');
    }

    function checklogin(Request $req)
    {
        try {
            //code...

            $credentials =['username' => $req->username, 'password' => $req->password];
            $api_key=env('REEL_STAR_API_KEY');
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL').'login',$credentials);
            
            if($response["code"]=="Admin_login_success"){
                 $req->session()->put("adminDetail",$response['data']);
                return redirect('index');
            } else{
                \Session::flash('message', 'Wrong credentials !');
                // Toastr::error(__('Wrong credentials !'));
                return redirect()->route('/');
            }

            // if($response['code']=="Admin_login_success"){
            //  $req->session()->put("adminDetail",$response['data']);
            // } else {
            //     Toastr::error(__('Wrong credentials !'));
            // }
        } catch (\Throwable $th) {
            throw $th;
        }
       
        // if (Auth::attempt($credentials ,false,false)) {

        //     $user = Auth::user();
          
        //     Session::put('user_id',  $user->user_id);
		// 	Session::put('user_type',  1);
           
          //$req->session()->put('user_id', $user->id);
          // $req->session()->put('user_type', 1);
        // $req->session()->put('user_password', $credentials['password']);
    
           
            // }else{
            //     Toastr::error(__('Wrong credentials !'));

            //     Session::flash('message', 'Wrong credentials !');
            //     return redirect()->route('/');
            // }





        // if ($data && $req->user_name == $data['user_name'] && md5($req->user_password) == $data['user_password']) {

          
        //     $req->session()->put('user_name', $data['user_name']);
        //     $req->session()->put('user_type', $data['user_type']);
        //     return  redirect('index');
        // } else {
        //     Session::flash('message', 'Wrong credentials !');
        //     return redirect()->route('/');
        // }
    }

    function index()
    {
        $api_key=env("REEL_STAR_API_KEY");
      
        $response=\Http::withHeaders(['Api_key' => $api_key])->get(env('API_BASE_URL')."dashboard");
        $dashboard=$response['data'];
        return view('index',['dashboard' => $dashboard]);
    }
    function logout()
    {
        // Auth::logout();
       // \Session::flush();
        session()->pull('user_name');
        session()->pull('user_password');
        session()->pull('user_type');
          session()->pull('user_id');
          session()->forget('adminDetail');
          session()->flush();
        return  redirect(url('/'));
    }
}
