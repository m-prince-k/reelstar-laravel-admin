<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SoundController extends Controller
{
    function showSounds()
    {
        //$soundCats = SoundCategories::where('is_deleted', 0)->get();
        return view('sounds');
    }
}
