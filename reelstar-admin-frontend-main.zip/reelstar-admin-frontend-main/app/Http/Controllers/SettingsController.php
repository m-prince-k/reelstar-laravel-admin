<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SettingsController extends Controller
{
    function notification()
    {
        return view('notification');
    }
    function coinPlans(Request $request)
    {
        $api_key=env("REEL_STAR_API_KEY");
        $response=\Http::withHeaders(['Api_key' => $api_key])->get(env("API_BASE_URL")."settings");
        $result=json_decode($response);
        $data=$result->data[0];
        

        return view('coinPlans',['coin_value' => $data->coin_value]);
    }

    function fetchCoinPlansList(Request $request)
    {
        try {
            //code...

            $nextpageState = $request->nextpageState;
            $startpageState = $request->startpageState;

            if ($request->input('draw') == 1) {
                $startpageState = 0;
                $nextpageState = 0;
            }

            $api_key=env("REEL_STAR_API_KEY");
            $response="";
            if($request->input('search.value')){
                $payload = [
                    'start' => $nextpageState,
                    "search" =>$request->input('search.value')
                ];
                $response=\Http::withHeaders(['Api_key' => $api_key])->post("https://reel-test.reelstar.io/api/v1/reel/"."fetchCoinPlans",$payload);
            } else {
                $response=\Http::withHeaders(['Api_key' => $api_key])->post("https://reel-test.reelstar.io/api/v1/reel/"."fetchCoinPlans");
            }

            $resultt=json_decode($response);
            $result = $resultt->data;

            $data = array();
            foreach ($result as $item) {
    
                $delete = '<a href=""class=" btn btn-danger text-white delete ml-2" rel=' . $item->coin_plan_id . ' >' . __("Delete") . '</a>';
                $edit = '<a href=""class=" btn btn-info text-white edit " rel=' . $item->coin_plan_id . ' >' . __("Edit") . '</a>';
                 
                $action=$delete . $edit;
    
                $data[] = array(
                    isset($item->coin_amount) ? $item->coin_amount : 'N/A',
                    isset($item->price) ? '$'.$item->price : 'N/A',
                    isset($item->playstore_product_id) ? $item->playstore_product_id : 'N/A',
                    isset($item->appstore_product_id) ? $item->appstore_product_id : 'N/A',
                    $action,
                );
            }
            $json_data = array(
                "draw"            => intval($request->input('draw')),
                "recordsTotal"    => intval($resultt->recordsTotal),
                "recordsFiltered" => isset($resultt->recordsTotal) ? $resultt->recordsTotal : '',
                "data"            => $data
            );
            echo json_encode($json_data);
            exit();
        } catch (\Throwable $th) {
            throw $th;
        }
    }



    function coinPackages(Request $request){
        try {
            //code...
            return view("coinPackages");
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function redeemRequests(Request $request) {
        try {
            //code...
            return view("redeemRequests");
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function fetchRedeemRequestsList(Request $request) {
        try {
            //code...
            $nextpageState = $request->nextpageState;
            $startpageState = $request->startpageState;
    
            if ($request->input('draw') == 1) {
                $startpageState = 0;
                $nextpageState = 0;
            }
      
            $api_key=env("REEL_STAR_API_KEY");
            
            $response='';
    
            if($request->input('search.value')){
                $payload = [
                    'start' => $nextpageState,
                    "search" =>$request->input('search.value')
                ];
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."getRadeemRequest",$payload);
            } else {
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."getRadeemRequest");
            }

            $result = json_decode($response);
            

            $result = $result->data;
             $data = [];
             $action = '';
             $data = array();
             $totalData=$result;
             $totalFiltered = $totalData;
           

             foreach ($result as $item) {

                if ($item->user && $item->user->profile_image != null) {
                    if(str_contains($item->user->profile_image,"https://d3ffhcda3vxwnb.cloudfront.net")){
                        $image = '<img src="'.$item->user->profile_image . '" width="50" height="50">';
                    } else {     
                        $image = '<img src="https://d3ffhcda3vxwnb.cloudfront.net/' .$item->user->profile_image . '" width="50" alt="user_icon" height="50">';
                    }
                } else {
                    $image = '<img src="http://placehold.jp/150x150.png" width="50" height="50" alt="dummy_account">';
                }
     
                 $identity = '<a href="' . route('viewUserDetails', isset($item->user_id) ? $item->user_id : '' ) . '" >' . $item->user->identity . '</a>';
                $complete="";
                if($item->status==0) {
                    $complete = '<a href="" class="btn btn-warning text-white complete" rel=' . $item->user_id . ' >' . __("Complete") . '</a>';
                } else {
                    $complete = '<a href="" class="btn btn-success text-white complete" rel=' . $item->user_id . ' >' . __("Complete") . '</a>';
                }

                
                  $reject = '<a href="" class=" btn btn-danger text-white rejectRadeem ml-2" rel=' . $item->user_id . ' >' . __("Reject") . '</a>';
     
                 $action = $complete." ".$reject;
             
                 $data[] = array(
                     $image,
                    isset($item->user->fullname) ?  $item->user->fullname : 'N/A',
                     isset($identity) ? $identity : 'N/A',
                     isset($item->gateway) ? $item->gateway : 'N/A',
                     isset($item->account) ? $item->account : 'N/A',
                     isset($item->amount) ? $item->amount : 'N/A',
                     $action,
     
                 );
             }
             $json_data = array(
                 "draw"            => intval($request->input('draw')),
                 "recordsTotal"    => isset($totalData) ? intval($totalData) : '',
                 "recordsFiltered" => isset($totalFiltered) ? $totalFiltered :'',
                 "data"            => $data
             );
             echo json_encode($json_data);
             exit();     

    } catch (\Throwable $th) {
            throw $th;
        }
    }

    function completeRedeemRequest($id){
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                'user_id' => $id,
                "type" => 1
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."completeRedeemRequest",$payload);
            return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function rejectRedeemRequest($id) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                'user_id' => $id,
                "type" => 2
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."completeRedeemRequest",$payload);
            return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }


    function addNewCoinPlan(Request $request){
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                "appstore_product_id" => $request->input('appstore_product_id'),
                "playstore_product_id" => $request->input('playstore_product_id'),
                "price" => $request->input('price'),
                "coin_amount" => $request->input('coin_amount')
            ];

            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."addCoinPlan",$payload);
            $result=json_decode($response);
            return $result;
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function deleteCoinPlan($id){
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                "coin_plan_id" => $id
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."deleteCoinPlan",$payload);
            return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function getCoinPlanById($id) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                "coin_plan_id" => $id
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."autoPopulateCoin",$payload);
            $resultt = json_decode($response);
           return $resultt->data;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function editCoinPlan(Request $request) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                "coin_plan_id" => $request->id,
                "coin_amount" => $request->coin_amount,
                "price" => $request->price,
                "playstore_product_id" => $request->playstore_product_id,
                "appstore_product_id" => $request->appstore_product_id 
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."editCoinPlan",$payload);
            return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    
    function fetchAdminNotificationsList(Request $request) {
        try {
            //code...

            $nextpageState=0;
            $startpageState=0;

            if ($request->input('draw') == 1) {
                $startpageState = 0;
                $nextpageState = 0;
            }

            $api_key=env("REEL_STAR_API_KEY");
            $response='';
            if($request->input('search.value')){
                $payload = [
                    'start' => $nextpageState,
                    "search" =>$request->input('search.value')
                ];
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."fetchAdminNotification",$payload);
            } else {
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."fetchAdminNotification");
            }

            $result = json_decode($response);
            $notifications = $result->data;

            $data = [];
            $action = '';
   
            foreach ($notifications as $key => $value) {

                $edit = '<a href=""class=" btn btn-info text-white edit ml-2" rel=' . $value->admin_notf_id . ' >' . __("Edit") . '</a>';
                $delete = '<a href=""class=" btn btn-danger text-white delete ml-2" rel=' . $value->admin_notf_id . ' >' . __("Delete") . '</a>';

                $action=$edit.$delete;

                $data[] = array(
                    $value->title ? \Str::ucfirst($value->title) : 'N/A',
                    $value->message ? \Str::ucfirst($value->message) : 'N/A',
                    $action
                    );
            }

            $json_data = array(
                "draw"            => intval($request->input('draw')),
                "recordsTotal"    => isset($result->recordsTotal) ?  intval($result->recordsTotal)*10 : '',
                "recordsFiltered" => isset($result->recordsFiltered) ?  $result->recordsFiltered*10 : '',
                "data"            => $data,
                "nextpageState"       => isset($result->pageState) ? $result->pageState : '',
                "startpageState"       => $startpageState || 0
             );
            echo json_encode($json_data);
            exit();

        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function addAdminNotification(Request $request) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            if($request->input('checkbox')=="All Users"){
                $payload = [
                    'title' => $request->input('title'),
                    "message" =>$request->input('message')
                ];
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."addAdminNotification",$payload);
            } else {
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."addAdminNotification");
            }
            return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function deleteAdminNotification($id) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $response='';
            $payload = ['admin_notify_id' => $id];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."deleteNotification",$payload);
            return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function getAdminNotificationById($id){
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $response='';
            $payload = ['admin_notify_id' => $id];

           
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."autoPopulateNotification",$payload);
           
           $result = json_decode($response);
           $resultant=$result->data[0];
            return $resultant;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function editAdminNotification(Request $request) {
        try {
            //code...
        $api_key=env("REEL_STAR_API_KEY");
            $response='';
           
            $payload = ['admin_notf_id' => $request->admin_notf_id,'title' => $request->title,'message' => $request->message];
           
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."editNotification",$payload);
            return $response;
         
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function fetchCoinPackages(Request $request) {
        try {
            //code...
            
            $nextpageState = $request->nextpageState;
            $startpageState = $request->startpageState;

            $api_key=env("REEL_STAR_API_KEY");
            $response="";
            if($request->input('search.value')){
                $payload = [
                    'start' => $nextpageState,
                    "search" =>$request->input('search.value')
                ];
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."getCoinPackages",$payload);
            } else {
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."getCoinPackages");
            }

            $resultt=json_decode($response);
            $result = $resultt->data;

            $data = array();
            foreach ($result as $item) {
    
                $delete = '<a href="" class=" btn btn-danger text-white delete ml-2" rel=' . $item->coin_packages_id . ' >' . __("Delete") . '</a>';
                $edit = '<a href="" class=" btn btn-info text-white edit " rel=' . $item->coin_packages_id . ' >' . __("Edit") . '</a>';

                $action=$delete." ".$edit;
    
                $data[] = array(
                    isset($item->coin_package_name) ? $item->coin_package_name : 'N/A',
                    isset($item->coin_amount) ? $item->coin_amount : 'N/A',
                    $action,
                );
            }
            $json_data = array(
                "draw"            => intval($request->input('draw')),
                "recordsTotal"    => intval($resultt->recordsTotal),
                "recordsFiltered" => isset($resultt->recordsTotal) ? $resultt->recordsTotal : '',
                "data"            => $data
            );
            echo json_encode($json_data);
            exit();

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function deleteCoinPackage($id) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $response='';
            $payload = ['coin_packages_id' => $id];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."deleteCoinPackage",$payload);
            return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function addNewCoinPackages(Request $request) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = [
                "package_name" => $request->input('package_name'),
                "package_amount" => $request->input('package_amount')
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."addCoinPackages",$payload);
            $result=json_decode($response);
            return $result;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function viewSettings(Request $request) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $response=\Http::withHeaders(['Api_key' => $api_key])->get(env("API_BASE_URL")."settings");
            $result=json_decode($response);
            $data=$result->data[0];
            
            return view("viewSettings",['data' => $data]);
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function updateGlobalSettings(Request $request) {
        try {
            //code...
    
            $api_key=env("REEL_STAR_API_KEY");
        
            $payload=[
                "setting_id" => $request->input('setting_id'),
                "currency" =>  $request->input('currency'),
                "coin_value" => $request->input('coin_value'),
                "min_fans_to_popular" => $request->input('min_fans_to_popular'),
                "min_fans_verification" => $request->input('min_fans_verification'),
                "min_redeem_coins" => $request->input('min_redeem_coins'),
                "reward_daily_check_in" => $request->input('reward_daily_check_in'),
                "reward_video_upload" => $request->input('reward_video_upload'),
                "max_upload_daily" => $request->input('max_upload_daily'),
                "androidversion" => $request->input('AndroidVersion'),
                "iosversion" => $request->input('IosVersion'),
                "admob_native" => $request->input('admob_native'),
                "admob_native_ios" => $request->input('admob_native_ios'),
                "live_min_viewers" => $request->input('live_min_viewers'),
                "live_timeout" => $request->input('live_timeout'),
                "app_status" => \Str::lower($request->input('app_status')),
                "app_url" => \Str::lower($request->input('app_url')),
                "app_message" => \Str::lower($request->input('app_message')),
                "post_like" => $request->input('post_like'),
                "post_comment" => $request->input("post_comment")
            ];
            

            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."updateSettings",$payload);
            $result=json_decode($response);
            return $result;
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    function getCoinPackagesById($id){
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload=['coin_packages_id' => $id];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."getCoinPackagesById",$payload);
            $resultt=json_decode($response);
            $result=$resultt->data;
            return $result;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function editCoinPackages(Request $request) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload=[
                "coin_packages_id" => $request->id,
                "coin_package_name" => $request->coin_package_name,
                "coin_amount" => $request->coin_package_amount
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."editCoinPackage",$payload);
            $result=json_decode($response);
           return $result;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function changeShowAdsStatus($id) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = ['ads_enabled' => (int)$id];
       
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env("API_BASE_URL")."settingAdsEnabledDisabled",$payload);
            $result=json_decode($response);
            return $result;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
}
