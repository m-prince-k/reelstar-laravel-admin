<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DataTables;
use Carbon\Carbon;


class UsersController extends Controller
{
    function users(Request $request)
    {
        return view('users');
    }
    function viewUserDetails(Request $request,$id)
    {
        try {
            //code...
            $nextpageState=0;
            $startpageState=0;
            
            $api_key=env("REEL_STAR_API_KEY");
            $payload=['user_id' => $id];    

            $response='';

            if($request->input('search.value')){
                $payload = [
                    'start' => $nextpageState,
                    "search" =>$request->input('search.value')
                ];
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."getPost",$payload);
            }

            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."viewUsers",$payload);
            $user = $response['data'];
            return view('viewUser',['user' => $user]);
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function editUserFromAdmin(Request $request){

        $api_key=env("REEL_STAR_API_KEY");
        $payload=['user_id' => $request->user_id,'fullname' => $request->fullname,'bio' => $request->bioUser];
        $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."editUser",$payload);
        return $response;
    }

    function fetchAllUsersList(Request $request) {
        $nextpageState=0;
        $startpageState=0;
        $currentpageState=0;
        $token = 0 ;
        $action = 'start';
        
        if($request->has('action') && $request->action == 'previous'){
            $startpageState = $request->startpageState;
            $nextpageState = $request->startpageState;
            $currentpageState = $request->startpageState;
            $action = 'previous';
            $token = $request->starttoken;
             //dd($startpageState , $nextpageState);

            //  $startpageState = $request->currentpageState;
            // $currentpageState = $request->nextpageState;
            // $nextpageState = $request->nextpageState;

        }elseif($request->has('action') && $request->action == 'next'){
            $startpageState = $request->currentpageState;
            $currentpageState = $request->nextpageState;
            $nextpageState = $request->nextpageState;
            $action = 'next';
            $token = $request->lasttoken;
        }

        // if($request->has('startpageState')){
            
        // }
       // $nextpageState = $request->nextpageState;
       

        if ($request->input('draw') == 1) {
            $startpageState = 0;
            $nextpageState = 0;
            $currentpageState=0;
            $action = 'start';
            $token = 0;
        }
  
        $api_key=env("REEL_STAR_API_KEY");
       
       $response='';
      
        if($request->input('search.value')){
            $payload = [
                'start' => $nextpageState,
                "search" =>$request->input('search.value'),
                "user_id" => $token, 
                "identifier" =>$action 
            ];
            //dd($payload);
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."users",$payload);
        } else if($request->input('from_date') && $request->input('to_date')) {
            $payload = [
                'start' => $nextpageState,
                "start_date" => $request->input('to_date'),
                "end_date" => $request->input('from_date'), 
                "user_id" => $token, 
                "identifier" =>$action 
            ];
            // dd($payload);
 
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."users",$payload);
        } else if($request->length){
            
            $payload=['start' => $nextpageState,'length' => $request->input('length'), "user_id" => $token, "identifier" =>$action ];
            
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."users",$payload);
            // dd($response);
        } else {
            $payload = ['start' => $nextpageState, "user_id" => $token, "identifier" =>$action ];
            // dd($payload);
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."users",$payload);
        }

        $result = json_decode($response);
        
       $users = $result->data;
       
       $previous=$nextpageState;
       
       $next="";
       if(isset($result->pageState)){
           $next=$result->pageState;
       }


        
    //    $request->session()->put("previous",0);

    //    if($request->session()->has('nextState')){
    //     $request->session()->put('previous',$next); 
    //    } 

    //    $request->session()->put('nextState',$next);

        $data = [];
        $action = '';

       
        foreach ($users as $key => $value) {
         
            if ($value->profile_image != null) {
                if(str_contains($value->profile_image,"https://d3ffhcda3vxwnb.cloudfront.net")){
                    $image = '<img src="'.$value->profile_image . '" width="50" height="50">';
                } else {     
                    $image = '<img src="https://d3ffhcda3vxwnb.cloudfront.net/' .$value->profile_image . '" width="50" height="50">';
                }
            } else {
                $image = '<img src="http://placehold.jp/150x150.png" width="50" height="50">';
            }

            if ($value->is_block == 1) {
                $block = '<a href="" class=" btn btn-success text-white unblock " rel=' . $value->user_id . ' >' . __("Unblock") . '</a>';
            } else {
                $block = '<a href="" class=" btn btn-danger text-white block " rel=' . $value->user_id . ' >' . __("Block") . '</a>';
            }

            $view = '<a href="' . route('viewUserDetails', $value->user_id) . '" class="mr-2 btn btn-info text-white " rel=' . $value->user_id . ' >' . __("View") . '</a>';

            $action = $view . $block;
           // Session::set(["startpageState" => '0','nextpageState'=>$result->pageState]);
            //session(['startpageState'=>'0','nextpageState'=>$result->pageState ]);
           

            $data[] = array(
                $image,
                isset($value->fullname) ? $value->fullname : '',
                isset($value->identity) ? $value->identity : '',
                isset($value->username) ? '@' . $value->username : '',
                isset($value->refferal->refferalUser->fullname) ? $value->refferal->refferalUser->fullname : 'N/A',
               // \Hashids::encode($value->user_id),
                isset($value->refferal->referral_code) ? $value->refferal->referral_code : '',
                isset($value->refferal->refferalCount) ? $value->refferal->refferalCount: 'N/A',
                date('d/m/Y h:i A',strtotime($value->created_at)),
                $action,
                );
                $lasttoken = $value->user_id;
        }
        //Session::put('nextpageState', $result->pageState);
    
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => isset($result->recordsTotal) ?  intval($result->recordsTotal)*10 : '',
            "recordsFiltered" => isset($result->recordsFiltered) ?  $result->recordsFiltered*10 : '',
            "data"            => $data,
            "nextpageState"       => isset($result->pageState) ? $result->pageState : '',
            "currentpageState" => $currentpageState,
            "startpageState"       => $startpageState,
            "start"       => $request->start,
            "starttoken"       => isset($users[0]->user_id) ? $users[0]->user_id : '',
            "lasttoken"       => isset($lasttoken) ? $lasttoken : '',
         );
        echo json_encode($json_data);
        exit();
    }
    function getAllUsers(Request $request) {
        try {
            //code...
      
            $api_key=env("REEL_STAR_API_KEY");
            $response="";
            if($request->limit) {
                $payload=['limit' => $request->limit];
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."allUser",$payload);
            } else {
                $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."allUser");
            }
            $result=json_decode($response);
            $responses=$result->data;
           return $responses;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function blockUnBlockUser ($id) {
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
            $payload = ['user_id' => $id];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."blockUnblockUser",$payload);
            return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }

}
