<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    function privacypolicy(Request $request){
        $data = Pages::first();
       return $data->privacy;
    }
    function viewPrivacy(Request $request){

        //$data = Pages::first();
        return view('viewPrivacy');    
    }
    function updatePrivacy(Request $request) {
        $api_key=env("REEL_STAR_API_KEY");
        $payload = [
            'privacy' => $request->privacy
        ];
        $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."privacyPolicy",$payload);
        return $response;
    }

    function updateTerms(Request $request) {
        $api_key=env("REEL_STAR_API_KEY");
        $payload = [
            'termsofuse' => $request->termsofuse
        ];
        $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."useOfTerms",$payload);
        return $response;
    }

    function viewTerms(Request $request){
        //$data = Pages::first();
        return view('viewTerms');
    }
}
