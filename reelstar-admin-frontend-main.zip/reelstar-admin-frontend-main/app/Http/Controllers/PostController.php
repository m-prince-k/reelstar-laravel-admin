<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;

class PostController extends Controller
{
    function showposts()
    {
        return view('posts');
    }
    function fetchAllPostsList(Request $request)
    {
        
        $nextpageState = $request->nextpageState;
        $startpageState = $request->startpageState;

        if ($request->input('draw') == 1) {
            $startpageState = 0;
            $nextpageState = 0;
        }
  
        $api_key=env("REEL_STAR_API_KEY");
        $payload = [
            'start' => $nextpageState
        ];

        $response='';

        if($request->input('search.value')){
            $payload = [
                'start' => $nextpageState,
                "search" =>$request->input('search.value')
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."getPost",$payload);
        } else if($request->to_date && $request->from_date) {
            $payload = [
                'start' => $nextpageState,
                "start_date" => new Carbon($request->input('to_date')),
                "end_date" => new Carbon($request->input('from_date'))
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."getPost",$payload);
           
        } else {
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."getPost",$payload);
        }

        $result = json_decode($response);
        
       $users = $result->data;
        $data = [];
        $action = '';



        foreach ($users as $key => $value) {
            if ($value->thumbnail != null) {
                if(str_contains($value->thumbnail,"https")){
                    $image = '<img src=' . $value->thumbnail . ' width="50" height="50">';
                } else {
                    $image = '<img src=https://d3ffhcda3vxwnb.cloudfront.net/' . $value->thumbnail . ' width="50" height="50">';
                }
            } else {
                $image = '<img src="http://placehold.jp/150x150.png" width="50" height="50">';
            }

            $contentUrl = $value->apivideourl;
            $content = '<a href="" class="ml-2 btn btn-info text-white view-content" data-url=' . $contentUrl . ' rel=' . $value->post_id . ' >' . __("View") . '</a>';
            $Delete = '<a href="" class="mr-2 btn btn-info text-white delete" rel=' . $value->post_id . ' >' . __("Delete") . '</a>';
            $action = $Delete;
           
           // Session::set(["startpageState" => '0','nextpageState'=>$result->pageState]);
            //session(['startpageState'=>'0','nextpageState'=>$result->pageState ]);
           if(isset($value->user->fullname)){
                $fullname=$value->user->fullname;
           } 
            $data[] = array(
                $content,
                $image,
                $value->user->identity ?? 'N/A',
                $fullname ? $fullname : 'N/A',
                $value->description ?? 'N\A',
               // \Hashids::encode($value->user_id),
                $value->views,
                $value->likes,
                $value->video_id ?? 'N/A',
                date('d/m/Y h:i A',strtotime($value->created_at)),
                $action,
    
                );
        }
        //Session::put('nextpageState', $result->pageState);
        
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($result->recordsTotal)*10,
            "recordsFiltered" => $result->recordsFiltered*10,
            "data"            => $data,
            "nextpageState"       => $result->pageState,
            "startpageState"       => $startpageState
        );
        echo json_encode($json_data);
        exit();
       
        //return $response;

        $totalData =  Users::count();
       // $rows = Users::orderBy('id', 'DESC')->get();

       // $result = $rows;

        $columns = array(
            0 => 'id',
            1 => 'fullname',
            2 => 'identity',
            3 => 'username',
            4=>'created_at'

        );

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');

        $from_date = $request->input('from_date');
        $to_date = $request->input('to_date');

        $totalFiltered = $totalData;
        if (empty($request->input('search.value')) && empty( $from_date) && empty($to_date)) {
            $result = Users::offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
        } else {
            $search = $request->input('search.value');
         
            $query =  Users::orderBy($order, $dir);

            if(!empty($from_date) && !empty($to_date))
            {
                $query->whereDate('created_at', '>=', "$from_date")
                ->whereDate('created_at', '<=', "$to_date");
            }
            if(!empty($search))
            {
                $query->Where('fullname', 'LIKE', "%{$search}%")
                ->orWhere('username', 'LIKE', "%{$search}%")
                ->orWhere('identity', 'LIKE', "%{$search}%")
                ->orWhere('id', 'LIKE', "%{$search}%");
            }
           
           // $query1 = str_replace(array('?'), array('\'%s\''), $query->toSql());
           // $query1 = vsprintf($query1, $query->getBindings());
           // print_R($query1);exit;
            
            $result =  $query->offset($start)->limit($limit)->get();



            $totalFiltered = $query->count();
        }
        $data = array();
        foreach ($result as $item) {


            $imgUrl = GlobalFunction::createMediaUrl($item->profile_image);

            if ($item->profile_image != null) {
                $image = '<img src="' . $imgUrl . '" width="50" height="50">';
            } else {
                $image = '<img src="http://placehold.jp/150x150.png" width="50" height="50">';
            }

            if ($item->is_block == 1) {
                $block = '<a href=""class=" btn btn-success text-white unblock " rel=' . $item->id . ' >' . __("Unblock") . '</a>';
            } else {
                $block = '<a href=""class=" btn btn-danger text-white block " rel=' . $item->id . ' >' . __("Block") . '</a>';
            }

            $identity = '<a href="' . route('viewUserDetails', $item->id) . '" >' . $item->identity . '</a>';


            $view = '<a href="' . route('viewUserDetails', $item->id) . '" class="mr-2 btn btn-info text-white " rel=' . $item->id . ' >' . __("View") . '</a>';


            $check_view = Admin::checkPermissionToLoggedUser('view_user_details');
            
            if( !$check_view )
            {
                $view = '';
            }
            $check_block = Admin::checkPermissionToLoggedUser('block-unblock-user');
            
            if( !$check_block )
            {
                $block = '';
            }

            $action = $view . $block;
            //dd($item->referrer->username);
            $data[] = array(
                $image,
                $item->fullname,
                $identity,
                '@' . $item->username,
                @$item->referrer->username,
                \Hashids::encode($item->id),
                $item->referrers_count,
                date('d/m/Y h:i A',strtotime($item->created_at)),
                $action,

            );
        }
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($totalData),
            "recordsFiltered" => $totalFiltered,
            "data"            => $data
        );
        echo json_encode($json_data);
        exit();
    }
    function deletePost(Request $request){

            $api_key=env("REEL_STAR_API_KEY");
            $payload = ['post_id' => $request->post_id,'user_id' => $request->user_id];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."deletePost",$payload);
            return $response;
    }
    function deletePostByUserId(Request $request) {
        $api_key=env("REEL_STAR_API_KEY");
        $payload = ['user_id' => $request->user_id,'post_id' => $request->post_id];
  
        $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."deletePostByUserId",$payload);
        return $response;
    }
    function verifyUserFromAdmin($id){
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
        $payload = [
            'user_id' => $id
        ];
        $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."verifyUser",$payload);
        return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function enabledDisabledAdmin($id){
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
        $payload = [
            'user_id' => $id
        ];
        $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."liveStreaming",$payload);
        return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function sponsorEnabled($id){
        try {
            //code...
            $api_key=env("REEL_STAR_API_KEY");
        $payload = [
            'user_id' => $id
        ];
        $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."sponsor",$payload);
        return $response;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function fetchUserPostList(Request $request) {
        $nextpageState = $request->nextpageState;
        $startpageState = $request->startpageState;

        if ($request->input('draw') == 1) {
            $startpageState = 0;
            $nextpageState = 0;
        }
  
        $api_key=env("REEL_STAR_API_KEY");
        $response="";
        if($request->userId && $request->length && $request->input('search.value')){
            $payload = [
                "user_id" => $request->input('userId'),
                "length" => $request->input('length'),
                "search" =>$request->input('search.value')
            ];

            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."postsByUserId",$payload);
        } else if($request->length){
            $payload = [
                "user_id" => $request->userId,
                "length" => $request->length
            ];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."postsByUserId",$payload);
        } else {
            $payload = ["user_id" => $request->userId,"length" => $request->length];
            $response=\Http::withHeaders(['Api_key' => $api_key])->post(env('API_BASE_URL')."postsByUserId",$payload);
        }
      
        $result = json_decode($response);
    

       $users = $result->data;
        $data = [];
        $action = '';
      
        foreach ($users as $item) {

            $contentUrl = $item->apivideourl;
            $content = '<a href="" class="ml-2 btn btn-info text-white view-content" data-url=' . $contentUrl . ' rel=' . $item->post_id . ' >' . __("View") . '</a>';
            
            if ($item->thumbnail != null) {
                if(str_contains($item->thumbnail,"https")){ 
                    $thumb = '<img src="'. $item->thumbnail. '" width="50" height="50" alt="_thumbnail">';
                } else {
                    $thumb = '<img src="https://d7htboz3ytb3i.cloudfront.net/'. $item->thumbnail  . '" width="50" height="50" alt="_thumbnail">';
                }
            }
            
            $delete = '<a rel='.$item->post_id.' class="btn btn-danger text-white delete-user-post" data-userId='.$item->user_id.'>' . __("Delete") . '</a>';
            

            $action = $delete;
            $usernamee="";
            $identityy="";
          
            if(!empty($item->users)){
                $usernamee=$item->users->username;
            } else {
                $usernamee='N/A';
            }
             if(!empty($item->users)){
                $identityy=$item->users->identity;
            }else {
                $identityy='N/A';
            }    

            $data[] = array(
                $content,
                $thumb,
                $identityy,
                $usernamee ? '@' . $usernamee : $usernamee,
                $item->description,
                $item->total_views,
                $item->total_likes,
                $item->created_at,
                $action
            );
        }
        //Session::put('nextpageState', $result->pageState);
        
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => isset($result->recordsTotal) ? intval($result->recordsTotal)*10 : '',
            "recordsFiltered" => isset($result->recordsFiltered) ?  $result->recordsFiltered*10 : '',
            "data"            => $data,
            "nextpageState"       => isset($result->pageState) ? $result->pageState : '',
            "startpageState"       => isset($startpageState) ? $startpageState : ''
        );
        echo json_encode($json_data);
        exit();
    }
}
