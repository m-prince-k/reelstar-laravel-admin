$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".customAdsSideA").addClass("activeLi");

    $("#adsTable").dataTable({
        language: {
            searchPlaceholder: "title or brand"
        },
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchAdsList`,
            data: function (data) {},
            error: (error) => {
                console.log(error);
            },
        },
    });

    $("#adsTable").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var itemId = $(this).attr("rel");
                    var url = `${domainUrl}deleteAd` + "/" + itemId;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#adsTable").DataTable().ajax.reload(null, false);

                        iziToast.success({
                            title: "Success!",
                            message: "Item Deleted successfully.",
                            position: "topRight",
                            timeOut: 4000,
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
    $("#adsTable").on("change", ".ad_status", function (event) {
        event.preventDefault();

        if (user_type == "1") {
            if ($(this).prop("checked") == true) {
                var value = 1;
            } else {
                value = 0;
            }
            var itemId = $(this).attr("rel");

            var url = `${domainUrl}changeAdStatus` + "/" + itemId + "/" + value;

            $.getJSON(url).done(function (data) {
                console.log(data);
                $("#adsTable").DataTable().ajax.reload(null, false);

                iziToast.success({
                    title: "Success!",
                    message: "Status Changed successfully.",
                    position: "topRight",
                    timeOut: 4000,
                });
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#PostsTable").on("click", ".view-content", function (event) {
        event.preventDefault();
        var contentUrl = $(this).data("url");
        var description = $(this).data("description");

        $("#videoDesc").text(description);
        $("#video source").attr("src", contentUrl);
        $("#video")[0].load();
        $("#video_modal").modal("show");
        $("#video").trigger("play");
    });

    $("#video_modal").on("hidden.bs.modal", function () {
        $("#video").trigger("pause");
    });
});
