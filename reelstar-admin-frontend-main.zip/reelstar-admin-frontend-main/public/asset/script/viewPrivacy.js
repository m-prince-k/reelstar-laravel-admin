$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".privacySideA").addClass("activeLi");

    $("#privacy").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();
        var privacy = $("#privacy_content").val(); 
        if(privacy.length==""){
            $("#privacy-content-data").text("Please enter the privacy policy")
        }
            $.ajax({
                url: domainUrl + "updatePrivacy",
                type: "POST",
                data: jQuery.param({privacy:JSON.stringify(privacy)}),
                dataType: "json",
                //contentType: false,
                cache: false,
                //processData: false,
                success: function (response) {
                    if(response.code=="privacy_added") {
                        iziToast.success({
                            message: response.message,
                            position: 'topRight'
                          });
                      location.reload();
                    } else {
                        iziToast.error({
                            message: response.message,
                            position: 'topRight'
                          });
                    }
                 
                },
                error: (error) => {
                    $(".loader").hide();
                    console.log(JSON.stringify(error));
                },
            });
        
    });
});
