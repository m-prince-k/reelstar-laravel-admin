$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".coinpurchasehistorySideA").addClass("activeLi");

    $("#table-22").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4, 5],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchCoinPurchaseHistoryList`,
            data: function (data) {},
        },
    });
});
