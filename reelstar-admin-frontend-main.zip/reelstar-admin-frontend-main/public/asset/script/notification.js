$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".notificationSideA").addClass("activeLi");

    $("#table-22").dataTable({
        language: {
            searchPlaceholder: "title"
        },
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchAdminNotificationsList`,
            data: function (data) { },
        },
    });

    $("#table-22").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                var id = $(this).attr("rel");
                var url = `${domainUrl}deleteAdminNotification` + "/" + id;

                $.getJSON(url).done(function (data) {
                    iziToast.success({
                        title: "Success!",
                        message: "Item deleted successfully.",
                        position: "topRight",
                    });
                    $("#table-22").DataTable().ajax.reload(null, false);
                });
            } else {
                swal("Yout item is safe !");
            }
        });
    });

    $("#submitNotificationForm").on("submit", function (event) {
        event.preventDefault();
        var formdata = new FormData($("#addForm")[0]);
        $.ajax({
            url: `https://reel-test.reelstar.io/api/v1/admin/addAdminNotification`,
            type: "POST",
            data: formdata,
            dataType: "json",
            contentType: false,
            cache: false,
            processData: false,
            success: function (response) {
                console.log("#addForm .form", "____________________________response is here", response);
                $("#table-22").DataTable().ajax.reload(null, false);
                $(".loader").hide();
                $("#additem").modal("hide");
                console.log($("#addForm.form"))
                $("#addForm.form").reset();

                if (response.status == false) {
                    iziToast.error({
                        title: app.Error,
                        message: response.message,
                        position: "topRight",
                    });
                } else {
                    iziToast.success({
                        title: "Success!",
                        message: "Item added successfully.",
                        position: "topRight",
                    });
                }
            },
            error: function (err) {
                console.log(err);
            },
        });
    });




    //add all users rendered in multi select
    $("#addItem").on("click", function (event) {
        var formdata = new FormData($("#addForm")[0]);

        $.ajax({
            url: `${domainUrl}getAllUsers`,
            type: "POST",
            data: formdata,
            dataType: "json",
            contentType: false,
            cache: false,
            processData: false,
            success: function (response) {
             
                // var ddlItems = document.getElementsByClassName("search-choice"),
                //     itemArray = response;
                    $("#all_users").each(function(){
                        response.push($(this).val());
                    });
                // $('#select_the_users').empty();
                // $("#select_the_users").append('<option>--Select Nation--</option>');
                // if(response)
                // {
                //     $.each(response,function(key,value){
                //         console.log(key,value)
                //         $('#select_the_users_chosen .chosen-drop')
                //         .append($(`<ul class="chosen-results"><li class='active-result' data-option-array-index=${key}>${value.fullname}</li></ul>`));
                //     });
                // }
            },
            error: function (err) {
                console.log(err);
            },
        });
        // $.getJSON(url).done(function (data) {

        // });
    });
    //end of all users rendered is here
    //$(document).ready(function(){


    //})



    $("#addForm").on("submit", function (event) {
        event.preventDefault();
        let checkbox = "";


        let title = $("#title").val();
        let message = $("#message").val();

        let payload = { checkbox: checkbox, title: title, message };

        var formdata = new FormData($("#addForm")[0]);

        $.ajax({
            url: `${domainUrl}addAdminNotification`,
            type: "POST",
            data: jQuery.param(payload),
            dataType: "json",
            //contentType: false,
            cache: false,
            // processData: false,
            success: function (response) {
                console.log(response);
                $("#table-22").DataTable().ajax.reload(null, false);
                $(".loader").hide();
                $("#additem").modal("hide");
                $("#addForm")[0].reset();

                if (response.status == false) {
                    iziToast.error({
                        title: app.Error,
                        message: response.message,
                        position: "topRight",
                    });
                } else {
                    iziToast.success({
                        title: "Success!",
                        message: "Item added successfully.",
                        position: "topRight",
                    });
                }
            },
            error: function (err) {
                console.log(err);
            },
        });

    });

    $("#table-22").on("click", ".edit", function (event) {
        event.preventDefault();

        $("#editForm")[0].reset();
        var id = $(this).attr("rel");

        $("#editId").val($(this).attr("rel"));


        var url = `${domainUrl}getAdminNotificationById` + "/" + id;
        $.getJSON(url).done(function (data) {
            var item = data;
            $("#edit_title").val(item.title);
            $("#edit_message").val(item.message);
        });
        $("#edititem").modal("show");
    });

    $("#editForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();


        var admin_notf_id = $("#editId").val();
        var title = $("#edit_title").val();
        var message = $("#edit_message").val();

        $.ajax({
            url: `${domainUrl}editAdminNotification`,
            type: "POST",
            data: jQuery.param({ admin_notf_id: admin_notf_id, title: title, message: message }),
            dataType: "json",
            //contentType: false,
            cache: false,
            //processData: false,
            success: function (response) {
                console.log(response);

                $(".loader").hide();
                $("#edititem").modal("hide");
                $("#editForm")[0].reset();

                if (response.code == "notify_updaetd") {
                    iziToast.success({
                        title: "Success!",
                        message: "Item updated successfully.",
                        position: "topRight",
                    });
                    $("#table-22").DataTable().ajax.reload(null, false);
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: response.message,
                        position: "topRight",
                    });
                }
            },
            error: function (err) {
                console.log(err);
            },
        });

    });
});