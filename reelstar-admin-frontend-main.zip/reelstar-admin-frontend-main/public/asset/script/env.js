var domainUrl = "/";
var sourceUrl = "https://reel-star.s3.ap-south-1.amazonaws.com";
var user_type = $('#user_type').val();

//console.log('user_type1' + user_type);
var app = {
    EntervailedPasswordandUsername: "Enter vailed Password and Username ",
    Error: "Error",
    Success: "Success",
    LoginSuccessfull: "Login Successfull",
    sure: "Are you sure?",
    Yourpackagehasbeendeleted: "Your Package has been deleted",
    tester: "You are Tester!",
    packageSafe: "Your Package is safe",
    minimumPackage: "minimumPackage",
    thisuserhasbeenunblocked: "this user has been unblocked",
    "thisusernotunblock ": "this user not unblock ",
    "noChangesDone ": "No changes done !",
    thisusernotblock: "this user not block ",
    thisuserhasbeenblocked: "this user has been blocked",
    YourInteresthasbeendeleted: "Your interest has been deleted",
    interestSafe: "Your interest is safe",
    minimumImage: "Minumum 1 image is required !",
    somethingWrong: "Something went wrong !",
    selectAtleastOneInterest: "Please select atleast one category !",
};

// add class on responsive

$(window).on("resize", function () {
    if ($(window).width() >= 1199) {
        $("table").removeClass("table-responsive");
    }

    if ($(window).width() <= 1199) {
        $("table").addClass("table-responsive");
    }
});
