$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");

    var adId = $("#itemId").val();
    var url = `${domainUrl}getAdById/` + adId;
    var ad;
    var is_android;
    var is_iOS;

    $.getJSON(url).done(function (data) {
        ad = data;
        console.log(data);

        is_android = ad.is_android;
        is_iOS = ad.is_ios;
        // console.log(is_android);
        // console.log(is_iOS);
    });

    

    $("#btn_cancel").on("click", function () {
        window.history.back();
    });

    $(document).on("change", "#androidSwitch", function (event) {
        event.preventDefault();

        if ($(this).prop("checked") == true) {
            is_android = 1;
            $("#android_link").prop("disabled", false);
        } else {
            is_android = 0;
            $("#android_link").prop("disabled", true);
        }
    });
    $(document).on("change", "#iosSwitch", function (event) {
        event.preventDefault();

        if ($(this).prop("checked") == true) {
            is_iOS = 1;
            $("#ios_link").prop("disabled", false);
        } else {
            is_iOS = 0;
            $("#ios_link").prop("disabled", true);
        }
    });

    $("#editCampaignForm").on("submit", function (event) {
        event.preventDefault();
        if (is_android == 0 && is_iOS == 0) {
            iziToast.error({
                title: "Attention!",
                message: "Please select campaign type! (Android, iOS)!",
                position: "topRight",
            });
            return;
        }
        if (is_android == 1 && $("#android_link").val() == "") {
            iziToast.error({
                title: "Attention!",
                message: "Please add value for android link!",
                position: "topRight",
            });
            return;
        }
        if (is_iOS == 1 && $("#ios_link").val() == "") {
            iziToast.error({
                title: "Attention!",
                message: "Please add value for iOS link!",
                position: "topRight",
            });
            return;
        }

        if (user_type == "1") {
            $(".loader").show();
            var formdata = new FormData($("#editCampaignForm")[0]);
            formdata.append("is_android", is_android);
            formdata.append("is_ios", is_iOS);

            $.ajax({
                url: `${domainUrl}editAdFromAdmin`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);

                    if (response.status == true) {
                        window.history.back();
                    } else {
                        $(".loader").hide();
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err.message);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#btn_play").on("click", function (event) {
        event.preventDefault();
        // var contentUrl = $(this).attr('rel');
        // $("#video source").attr("src", contentUrl);
        $("#video_modal").modal("show");
        $("#advideo")[0].load();
        $("#advideo").trigger("play");
    });

    $("#video_modal").on("hidden.bs.modal", function () {
        $("#advideo").trigger("pause");
    });

    // On brand logo change
    var brandLogoInput = $("#brand_logo");
    brandLogoInput.change(function () {
        if (brandLogoInput[0].files && brandLogoInput[0].files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $("#brand_logo_img").attr("src", e.target.result);
            };
            reader.readAsDataURL(brandLogoInput[0].files[0]);
            console.log(brandLogoInput[0].files[0]);
        }
    });
    // On Horizintal Image change
    var horizontalImageInput = $("#horizontal_image");
    horizontalImageInput.change(function () {
        if (horizontalImageInput[0].files && horizontalImageInput[0].files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $("#horizontal_image_img").attr("src", e.target.result);
            };
            reader.readAsDataURL(horizontalImageInput[0].files[0]);
            console.log(horizontalImageInput[0].files[0]);
        }
    });
    // On Vertical Image change
    var verticalImageInput = $("#vertical_image");
    verticalImageInput.change(function () {
        if (verticalImageInput[0].files && verticalImageInput[0].files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $("#vertical_image_img").attr("src", e.target.result);
            };
            reader.readAsDataURL(verticalImageInput[0].files[0]);
            console.log(verticalImageInput[0].files[0]);
        }
    });
});
