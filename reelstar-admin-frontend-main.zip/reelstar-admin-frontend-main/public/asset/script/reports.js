$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".reportSideA").addClass("activeLi");

    $("#PostReportsTable").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4, 5, 6, 7, 8],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchPostReportsList`,
            data: function (data) {},
            error: (error) => {
                console.log(error);
            },
        },
    });

    $("#UserReportsTable").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4, 5],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchUserReportsList`,
            data: function (data) {},
            error: (error) => {
                console.log(error);
            },
        },
    });

    $("#PostReportsTable").on("click", ".view-content", function (event) {
        event.preventDefault();
        var contentUrl = $(this).data("url");
        var description = $(this).data("description");

        $("#videoDesc").text(description);
        $("#video source").attr("src", contentUrl);
        $("#video")[0].load();
        $("#video_modal").modal("show");
    });

    $("#video_modal").on("hidden.bs.modal", function () {
        $("#video").trigger("pause");
    });

    $("#PostReportsTable").on("click", ".delete-report", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var dleete_url = `${domainUrl}deletePostReport` + "/" + id;

                    $.getJSON(dleete_url).done(function (data) {
                        console.log(data);
                        $("#PostReportsTable")
                            .DataTable()
                            .ajax.reload(null, false);

                        iziToast.success({
                            title: "Success!",
                            message: "Report deleted successfully.",
                            position: "topRight",
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
    $("#UserReportsTable").on("click", ".block-user", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}blockUserByReport` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#UserReportsTable")
                            .DataTable()
                            .ajax.reload(null, false);

                        iziToast.success({
                            title: "Success!",
                            message: "User blocked successfully.",
                            position: "topRight",
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
    $("#UserReportsTable").on("click", ".delete-report", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var dleete_url = `${domainUrl}deleteUserReport` + "/" + id;

                    $.getJSON(dleete_url).done(function (data) {
                        console.log(data);
                        $("#UserReportsTable")
                            .DataTable()
                            .ajax.reload(null, false);

                        iziToast.success({
                            title: "Success!",
                            message: "Report deleted successfully.",
                            position: "topRight",
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
    $("#PostReportsTable").on("click", ".delete-post", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var post_id = $(this).attr("data-postId");
                    var user_id = $(this).attr("data-userId");

                    var url = `${domainUrl}deletePost`;
                    var formdata = new FormData();
                    formdata.append("user_id", user_id);
                    formdata.append("post_id", post_id);

                    $.ajax({
                        url: url,
                        type: "POST",
                        data: formdata,
                        dataType: "json",
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (response) {
                            console.log(response);

                            iziToast.success({
                                title: "Success!",
                                message: "Post deleted successfully.",
                                position: "topRight",
                            });

                            // var id = $(this).attr("rel");
                            var delete_url =
                                `${domainUrl}deleteAllReportsOfPost` +
                                "/" +
                                post_id;

                            $.getJSON(delete_url).done(function (data) {
                                console.log(data);
                                $("#PostReportsTable")
                                    .DataTable()
                                    .ajax.reload(null, false);
                            });

                            if (response.status == false) {
                                iziToast.error({
                                    title: app.Error,
                                    message: response.message,
                                    position: "topRight",
                                });
                            }
                        },
                        error: function (err) {
                            console.log(err);
                        },
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
    $("#UsersTable").on("click", ".block", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                swal("User blocked Successfully", {
                    icon: "success",
                });

                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var delete_cat_url = `${domainUrl}blockUser` + "/" + id;

                    $.getJSON(delete_cat_url).done(function (data) {
                        console.log(data);
                        $("#UsersTable").DataTable().ajax.reload(null, false);
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
});
