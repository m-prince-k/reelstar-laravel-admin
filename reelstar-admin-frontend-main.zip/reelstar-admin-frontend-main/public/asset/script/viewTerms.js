$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".termsSideA").addClass("activeLi");

    $("#terms").on("submit", function (event) {
        event.preventDefault();
            var termofuse = $("#termsContent").val();
            $.ajax({
                url: domainUrl + "updateTerms",
                type: "POST",
                data: jQuery.param({termsofuse:termofuse}),
                dataType: "json",
                //contentType: false,
                cache: false,
                //processData: false,
                success: function (response) {
                    if(response.code=="privacy_added") {
                        iziToast.success({
                            message:response.message,
                            position: "topRight",
                        });
                        location.reload();
                    }
                    // $(".loader").hide();
                    //location.reload();
                },
                error: (error) => {
                    $(".loader").hide();
                    console.log(JSON.stringify(error));
                },
            });
       
    });
});
