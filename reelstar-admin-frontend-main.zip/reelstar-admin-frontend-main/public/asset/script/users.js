$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".usersSideA").addClass("activeLi");


    var tab = $("#UsersTable").dataTable({
        language: {
            searchPlaceholder: "fullname or username"
        },
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        pagingType: "simple",
        columnDefs: [
            {   
                targets: [0, 4],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchAllUsersList`,
            data: function (d) {
               // const pageInfo = dataTable.page.info();
               console.log(d);
                d.from_date = $('#from_date').val();
                d.to_date = $('#to_date').val();
                d.nextpageState =$('#UsersTable_next').data('info');
                d.startpageState = $('#UsersTable_previous').data('info');
                d.currentpageState = $('#UsersTable').data('current');
                d.starttoken = $('#UsersTable').data('starttoken');
                d.lasttoken = $('#UsersTable').data('lasttoken');
                
                var draw = $('#UsersTable').data('info');
                console.log(draw,d.start);
                d.action = "next";
                if (draw > d.start) {
                    d.action = "previous";
                }else if (d.start == 0) {
                    d.action = "start";
                }
                
            },
            // "success": function (response) {
            //    // console.log(response.nextpageState);
            //     // return response;
            // },
            error: (error) => {
                console.log("________________error is here",error);
            },
        },
        "drawCallback": function (settings) { 
            // Here the response
           var response = settings.json;
            var nextpageState = response.nextpageState;
            var currentpageState = response.currentpageState;
            var startpageState = response.startpageState ? response.startpageState : 0 ;
            
            $('#UsersTable_next').data('info', nextpageState);
            $('#UsersTable_previous').data('info', startpageState);
            $('#UsersTable').data('info', response.start);
            $('#UsersTable').data('starttoken', response.starttoken);
            $('#UsersTable').data('lasttoken', response.lasttoken);
            $('#UsersTable').data('current', currentpageState);
        },
    });


    $('#filter').click(function(){
        var from_date = $('#from_date').val();
        var to_date = $('#to_date').val();
   
       
   
        if(from_date != '' &&  to_date != '')
        {
           if(from_date > to_date){
               $("#error_log").html("Warning: End date should be greater then start date.");
           }else{
              $("#error_log").html(""); 
              tab.fnDraw();
           }
   
         
        }
        else
        {
         alert('Both Date is required');
        }
       });

       

    $("#UsersTable").on("click", ".block", function (event) {
        event.preventDefault();
     

        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                //if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var delete_cat_url = `${domainUrl}blockUnBlockUser` + "/" + id;

                    $.getJSON(delete_cat_url).done(function (data) {
                  
                        $("#UsersTable").DataTable().ajax.reload(null, false);

                        iziToast.success({
                            title: "Success!",
                            message: data.message,
                            position: "topRight",
                        });
                    });
                // } else {
                //     iziToast.error({
                //         title: app.Error,
                //         message: app.tester,
                //         position: "topRight",
                //     });
                // }
            }
        });
    });

    $("#UsersTable").on("click", ".unblock", function (event) {
        event.preventDefault();

        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                //if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var delete_cat_url = `${domainUrl}blockUnBlockUser` + "/" + id;

                    $.getJSON(delete_cat_url).done(function (data) {
                        console.log(data);
                        $("#UsersTable").DataTable().ajax.reload(null, false);
                        iziToast.success({
                            title: "Success!",
                            message: data.message,
                            position: "topRight",
                        });
                    });
                // } else {
                //     iziToast.error({
                //         title: app.Error,
                //         message: app.tester,
                //         position: "topRight",
                //     });
                // }
            }
        });
    });
});