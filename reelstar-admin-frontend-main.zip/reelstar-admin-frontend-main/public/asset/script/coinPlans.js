$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".coinPlansSideA").addClass("activeLi");

    $("#table-22").dataTable({
        language: {
            searchPlaceholder: "Enter product id"
        },
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchCoinPlansList`,
            data: function (data) {},
        },
    });

    $("#table-22").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}deleteCoinPlan` + "/" + id;
                    $.getJSON(url).done(function (data) {
                        if(data.code=="coin_plan_deleted"){
                            iziToast.success({
                                title: "Success!",
                                message: "Item Deleted successfully.",
                                position: "topRight",
                            });
                            $("#table-22").DataTable().ajax.reload(null, false);
                        } else {
                            iziToast.error({
                                title: "Error!",
                                message: "Something went wrong!",
                                position: "topRight",
                                timeOut: 4000,
                            });
                        }
                    });

                  
              
            } else {
                swal("Yout item is safe !");
            }
        });
    });

    $("#addForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

            var formdata = new FormData($("#addForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}addNewCoinPlan`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    if (response.code == "coin_plan_created") {
                        iziToast.success({
                            title: "Success!",
                            message: "Item Added successfully.",
                            position: "topRight",
                        });
                        $("#table-22").DataTable().ajax.reload(null, false);
                        $(".loader").hide();
                        $("#additem").modal("hide");
                        $("#addForm")[0].reset();


                        $("#coin_price").reset()
                        $("#edit_price").reset()
                    } else {
                        iziToast.error({
                            title: app.Error,
                            message: app.tester,
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
      
    });

    $("#table-22").on("click", ".edit", function (event) {
        event.preventDefault();

        $("#editForm")[0].reset();
        var id = $(this).attr("rel");

        $("#editId").val($(this).attr("rel"));

        var url = `${domainUrl}getCoinPlanById` + "/" + id;

        $.getJSON(url).done(function (data) {
            var item = data;
            $("#edit_coin_amount").val(item.coin_amount);
            $("#edit_price").val(item.price);
            $("#edit_android_product_id").val(item.playstore_product_id);
            $("#edit_ios_product_id").val(item.appstore_product_id);
        });
        $("#edititem").modal("show");
    });

    $("#editForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

       
            var formdata = new FormData($("#editForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}editCoinPlan`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
               

                    if (response.code == "coin_plan_updated") {
                        iziToast.success({
                            title: "Success!",
                            message: "Item edited successfully.",
                            position: "topRight",
                        });
                        $("#table-22").DataTable().ajax.reload(null, false);
                        $(".loader").hide();
                        $("#edititem").modal("hide");
                        $("#editForm")[0].reset();
                    } else {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        
    });
});