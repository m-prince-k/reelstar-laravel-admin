$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".livestreamUsersSideA").addClass("activeLi");
    $(document).on("click",".rejectall",function() {
          swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    //var id = $('this').attr("rel");
                    var ids = [];
                    // Read all checked checkboxes4

                    $("input[name='delete_check[]']:checked").each(function () {
                        ids.push($(this).val());
                    });
                  
                    var url = `${domainUrl}deleteLiveStreamUsers` + "?ids=" + ids;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-23").DataTable().ajax.reload(null, false);
                    });

                    iziToast.success({
                        title: "Success!",
                        message: "Request Deleted successfully.",
                        position: "topRight",
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
    // $("#table-23").dataTable({
    //     processing: true,
    //     serverSide: false,
    //     serverMethod: "post",
    //     aaSorting: [[1, "desc"]],
    //     columnDefs: [
    //         {
    //             targets: 0,
    //             //orderable: false,
    //             'checkboxes': {
    //                 'selectRow': true
    //              }
    //         },
    //     ],
    //     select: {
    //         style: 'os',
    //         selector: 'td:first-child'
    //       },
    //     ajax: {
    //         url: `${domainUrl}fetchLiveStreamUsersList`,
    //         data: function (data) {},
    //     },
    // });
    var table = $('#table-23').DataTable({
        dom: 'l<"toolbar">frtip',
        initComplete: function(){
        $("div.toolbar")
         .html('<a href="javascript:void(0);" class=" btn btn-danger text-white rejectall ml-2">Delete</a>');           
        },
        'ajax': {
                    url: `${domainUrl}fetchLiveStreamUsersList`,
                    type: 'POST',
                    data: function (data) {},
                },
        'columnDefs': [
           {
              'targets': 0,
              'checkboxes': {
                 'selectRow': true
              }
           }
        ],
        select: {
            style: 'multi'
        },    
        'order': [[1, 'asc']]
     });

  
    $("#table-23").on("click", ".reject", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                //if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}closeLiveStreamUser` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-23").DataTable().ajax.reload(null, false);
                    });

                    iziToast.success({
                        title: "Success!",
                        message: "Request delete successfully.",
                        position: "topRight",
                    });
               // } else {
                   // iziToast.error({
                //         title: app.Error,
                //         message: app.tester,
                //         position: "topRight",
                //     });
                // }
            }
        });
    });
    $('#checkall').click(function(){
        if($(this).is(':checked')){
           $('.delete_check').prop('checked', true);
           $('tr').addClass('selected');
        }else{
           $('.delete_check').prop('checked', false);
           $('tr').removeClass('selected');
        }
     });
     
   // Checkbox checked
// function checkcheckbox(){

//     // Total checkboxes
//     var length = $('.delete_check').length;
 
//     // Total checked checkboxes
//     var totalchecked = 0;
//     $('.delete_check').each(function(){
//        if($(this).is(':checked')){
//           totalchecked+=1;
//        }
//     });
 
//     // Checked unchecked checkbox
//     if(totalchecked == length){
//        $("#checkall").prop('checked', true);
//     }else{
//        $('#checkall').prop('checked', false);
//     }
//  }
});
