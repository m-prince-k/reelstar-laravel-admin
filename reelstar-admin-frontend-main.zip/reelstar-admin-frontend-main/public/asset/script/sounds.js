$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".soundsSideA").addClass("activeLi");

    // Fetch Sound Categories
    var url = `${domainUrl}getSoundCategories`;
    var soundCategories;
    $.getJSON(url).done(function (data) {
        soundCategories = data.data;
    });

    $("#SoundCategoriesTable").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchAllSoundCategoriesList`,
            data: function (data) {},
            error: (error) => {
                console.log(error);
            },
        },
    });
    var tab =  $("#SoundsTable").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4, 5, 6, 7],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchAllSoundList`,
            data: function (d) {
                d.from_date = $('#from_date').val();
                d.to_date = $('#to_date').val();
                
            },
            error: (error) => {
                console.log(error);
            },
        },
    });

    $('#filter').click(function(){
        var from_date = $('#from_date').val();
        var to_date = $('#to_date').val();
   
       
   
        if(from_date != '' &&  to_date != '')
        {
           if(from_date > to_date){
               $("#error_log").html("Warning: End date should be greater then start date.");
           }else{
              $("#error_log").html(""); 
              tab.fnDraw();
           }
   
         
        }
        else
        {
         alert('Both Date is required');
        }
       });

       

    function handleFiles(event) {
        var files = event.target.files;
        $("#view-sound").attr("src", URL.createObjectURL(files[0]));
        document.getElementById("view-sound").load();
    }

    $("#sound").on("change", handleFiles, false);

    var editSoundImageInput = $("#editImage");
    editSoundImageInput.change(function () {
        if (editSoundImageInput[0].files && editSoundImageInput[0].files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $("#sound-img-view").attr("src", e.target.result);
            };
            reader.readAsDataURL(editSoundImageInput[0].files[0]);
            console.log(editSoundImageInput[0].files[0]);
        }
    });

    var editSoundFileInput = $("#editSound");
    editSoundFileInput.change(function () {
        if (editSoundFileInput[0].files && editSoundFileInput[0].files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $("#view-sound").attr("src", e.target.result);
            };
            reader.readAsDataURL(editSoundFileInput[0].files[0]);
            console.log(editSoundFileInput[0].files[0]);
        }
    });

    var editSoundCatImageInput = $("#edit_sound_category_profile");
    editSoundCatImageInput.change(function () {
        if (
            editSoundCatImageInput[0].files &&
            editSoundCatImageInput[0].files[0]
        ) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $("#sound-cat-img-view").attr("src", e.target.result);
            };
            reader.readAsDataURL(editSoundCatImageInput[0].files[0]);
            console.log(editSoundCatImageInput[0].files[0]);
        }
    });

    $("#SoundsTable").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var cat_id = $(this).attr("rel");
                    var delete_cat_url =
                        `${domainUrl}deleteSound` + "/" + cat_id;

                    $.getJSON(delete_cat_url).done(function (data) {
                        console.log(data);
                        $("#SoundsTable").DataTable().ajax.reload(null, false);

                        iziToast.success({
                            title: "Success!",
                            message: "Item Deleted successfully.",
                            position: "topRight",
                            timeOut: 4000,
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
    $("#SoundCategoriesTable").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var cat_id = $(this).attr("rel");
                    var delete_cat_url =
                        `${domainUrl}deleteSoundCategory` + "/" + cat_id;

                    $.getJSON(delete_cat_url).done(function (data) {
                        console.log(data);
                        $("#SoundCategoriesTable")
                            .DataTable()
                            .ajax.reload(null, false);

                        iziToast.success({
                            title: "Success!",
                            message: "Item Deleted successfully.",
                            position: "topRight",
                            timeOut: 4000,
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });

    document.addEventListener(
        "play",
        function (e) {
            var audios = document.getElementsByTagName("audio");
            for (var i = 0, len = audios.length; i < len; i++) {
                if (audios[i] != e.target) {
                    audios[i].pause();
                }
            }
        },
        true
    );

    $("#SoundsTable").on("click", ".edit", function (event) {
        event.preventDefault();
        $("#editSoundForm")[0].reset();
        var id = $(this).attr("rel");

        $("#editSoundId").val($(this).attr("rel"));

        var url = `${domainUrl}getSoundById` + "/" + id;

        $("#editSoundCatSelect").empty();

        $.getJSON(url).done(function (data) {
            var soundData = data.data;
            console.log(soundData);
            var imgUrl = sourceUrl + soundData.image;
            var soundUrl = sourceUrl + soundData.sound;

            $("#editSoundTitle").val(soundData.title);
            $("#editSoundDuration").val(soundData.duration);
            $("#editSoundSinger").val(soundData.singer);
            // Setting Image and Audio
            $("#sound-img-view").attr("src", imgUrl);
            $("#view-sound").attr("src", soundUrl);

            // Seting Categories Options
            $.each(soundCategories, function (indexInArray, category) {
                $("#editSoundCatSelect").append(`
                    <option ${
                        category.id == soundData.category.id ? "selected" : ""
                    } value="${category.id}">${category.sound_category_name}</option>
                `);
            });
        });

        $("#editSoundItem").modal("show");
    });

    $("#SoundCategoriesTable").on("click", ".edit", function (event) {
        event.preventDefault();
        var title = $(this).attr("data-title");
        var imageUrl = $(this).attr("data-image");

        $("#editId").val($(this).attr("rel"));
        $("#edit_sound_category_name").val(title);
        $("#edititem").modal("show");
        $("#sound-cat-img-view").attr("src", imageUrl);
    });

    $("#editSoundForm").on("submit", function (event) {
        event.preventDefault();
        if (user_type == 1) {
            var formdata = new FormData($("#editSoundForm")[0]);
            console.log(formdata);
            $(".loader").show();
            $.ajax({
                url: `${domainUrl}editSound`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#SoundsTable").DataTable().ajax.reload(null, false);
                    $(".loader").hide();
                    $("#editSoundItem").modal("hide");

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Successful!",
                            message: "Item updated Successfully !",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });
    $("#addSoundForm").on("submit", function (event) {
        event.preventDefault();
        if (user_type == 1) {
            var formdata = new FormData($("#addSoundForm")[0]);
            console.log(formdata);
            $(".loader").show();

            $.ajax({
                url: `${domainUrl}addSoundFromAdmin`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#SoundsTable").DataTable().ajax.reload(null, false);
                    $(".loader").hide();
                    $("#addSoundItem").modal("hide");
                    $("#addSoundForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Successful!",
                            message: "Item added Successfully !",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#addForm").on("submit", function (event) {
        event.preventDefault();
        if (user_type == 1) {
            var formdata = new FormData($("#addForm")[0]);
            console.log(formdata);
            $(".loader").show();

            $.ajax({
                url: `${domainUrl}addSoundCategory`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#SoundCategoriesTable")
                        .DataTable()
                        .ajax.reload(null, false);
                    $(".loader").hide();
                    $("#additem").modal("hide");
                    $("#addForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Successful!",
                            message: "Item added Successfully !",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#editForm").on("submit", function (event) {
        event.preventDefault();
        if (user_type == 1) {
            var formdata = new FormData($("#editForm")[0]);
            console.log(formdata);
            $(".loader").show();

            $.ajax({
                url: `${domainUrl}editSoundCategory`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#SoundCategoriesTable")
                        .DataTable()
                        .ajax.reload(null, false);
                    $(".loader").hide();
                    $("#edititem").modal("hide");

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Successful!",
                            message: "Item edited Successfully !",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#add-sound-cat").on("click", function (event) {
        $("#additem").modal("show");
    });
    $("#add-sound").on("click", function (event) {
        $("#addSoundItem").modal("show");
    });

    $("#PostsTable").on("click", ".view-content", function (event) {
        event.preventDefault();
        var contentUrl = $(this).data("url");
        var description = $(this).data("description");

        $("#videoDesc").text(description);
        $("#video source").attr("src", contentUrl);
        $("#video")[0].load();
        $("#video_modal").modal("show");
    });

    $("#video_modal").on("hidden.bs.modal", function () {
        $("#video").trigger("pause");
    });
});
