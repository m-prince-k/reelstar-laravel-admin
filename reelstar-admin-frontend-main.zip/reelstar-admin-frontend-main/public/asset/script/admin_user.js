$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".adminUsersSideA").addClass("activeLi");

    var tab = $("#AdminUsersTable").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 2],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchAllAdminUserList`,
            data: function (d) {
                d.from_date = $('#from_date').val();
                d.to_date = $('#to_date').val();
                
            },
            error: (error) => {
                console.log(error);
            },
        },
    });

    $('#filter').click(function(){
        var from_date = $('#from_date').val();
        var to_date = $('#to_date').val();
   
       
   
        if(from_date != '' &&  to_date != '')
        {
           if(from_date > to_date){
               $("#error_log").html("Warning: End date should be greater then start date.");
           }else{
              $("#error_log").html(""); 
              tab.fnDraw();
           }
   
         
        }
        else
        {
         alert('Both Date is required');
        }
       });


  
});
