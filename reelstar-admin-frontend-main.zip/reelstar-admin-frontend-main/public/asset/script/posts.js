$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".postsSideA").addClass("activeLi");

    var tab =  $("#PostsTable").dataTable({
        language: {
            searchPlaceholder: "description"
        },
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4, 7, 8,9],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchAllPostsList`,
            data: function (d) {
                d.from_date = $('#from_date').val();
                d.to_date = $('#to_date').val();
                
            },
            error: (error) => {
                console.log(error);
            },
        },
    });
   
    $('#filter').click(function(){
     var from_date = $('#from_date').val();
     var to_date = $('#to_date').val();

    

     if(from_date != '' &&  to_date != '')
     {
        if(from_date > to_date){
            $("#error_log").html("Warning: End date should be greater then start date.");
        }else{
           $("#error_log").html(""); 
           tab.fnDraw();
        }

     }
     else
     {
      alert('Both Date is required');
     }
    });


   

    $("#PostsTable").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                    var post_id = $(this).attr("rel");
                    var user_id = $(this).attr("data-userId");
                    var url = `${domainUrl}deletePost`;

                $.ajax({
                        url: url,
                        type: "POST",
                        data:  jQuery.param({post_id:post_id,user_id:user_id}),
                        dataType: "json",
                        //contentType: 'application/json; charset=utf-8',
                        //contentType: false,
                        cache: false,
                        processData: false,
                        success: function (response) {
                            if (response.status == false) {
                                iziToast.error({
                                    title: app.Error,
                                    message: response.message,
                                    position: "topRight",
                                });
                            } else {
                                iziToast.success({
                                    title: "Success!",
                                    message: "Post deleted successfully.",
                                    position: "topRight",
                                });
                                $("#PostsTable").DataTable().ajax.reload(null, false);
                            }
                        },
                        error: function (err) {
                            console.log("_____________________________________error is here",err);
                        },
                    });
               
            }
        });
    });

    $("#PostsTable").on("click", ".view-content", function (event) {
        event.preventDefault();
        var contentUrl = $(this).data("url");
        var description = $(this).data("description");

        $("#videoDesc").text(description);
        $("#video source").attr("src", contentUrl);
        $("#video")[0].load();
        $("#video_modal").modal("show");
        $("#video").trigger("play");
    });

    $("#video_modal").on("hidden.bs.modal", function () {
        $("#video").trigger("pause");
    });
});