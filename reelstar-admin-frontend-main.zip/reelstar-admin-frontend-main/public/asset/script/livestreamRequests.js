$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".livestreamRequestsSideA").addClass("activeLi");

    $("#table-22").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchLiveStreamRequestsList`,
            data: function (data) {},
        },
    });

    $("#table-22").on("click", ".reject", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}rejectLiveStreamRequest` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-22").DataTable().ajax.reload(null, false);
                    });

                    iziToast.success({
                        title: "Success!",
                        message: "Request rejected successfully.",
                        position: "topRight",
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });

    $("#table-22").on("click", ".approve", function (event) {
        event.preventDefault();

        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}approveLiveStreamRequest` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-22").DataTable().ajax.reload(null, false);
                    });
                    $("#edititem").modal("show");

                    iziToast.success({
                        title: "Success!",
                        message: "Request Approved successfully.",
                        position: "topRight",
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
});
