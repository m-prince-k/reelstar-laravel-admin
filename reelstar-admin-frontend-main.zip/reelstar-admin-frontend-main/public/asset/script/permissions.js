$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".permissionsSideA").addClass("activeLi");

    $("#PermissionsTable").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchAllPermissionsList`,
            data: function (data) {},
            error: (error) => {
                console.log(error);
            },
        },
    });

  
});
