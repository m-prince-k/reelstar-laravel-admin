$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".rolesSideA").addClass("activeLi");

    $("#RolesTable").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 2],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchAllRolesList`,
            data: function (data) {},
            error: (error) => {
                console.log(error);
            },
        },
    });

    $("#checkPermissionAll").click(function(){
		if($(this).is(':checked'))
		{
			$('input[type=checkbox]').prop('checked', true)
		}else
		{
			$('input[type=checkbox]').prop('checked', false)
		}
	})
    

  
});
