$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".coinPackagesSideA").addClass("activeLi");

    $("#table-222").dataTable({
        language: {
            searchPlaceholder: "Package Name"
        },
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchCoinPackages`,
            data: function (data) {},
        },
    });

    $("#table-222").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}deleteCoinPackage` + "/" + id;
                    $.getJSON(url).done(function (data) {
                        if(data.code=="coin_packages_delete"){
                            iziToast.success({
                                title: "Success!",
                                message: "Item Deleted successfully.",
                                position: "topRight",
                            });
                            $("#table-222").DataTable().ajax.reload(null, false);
                        } else {
                            iziToast.error({
                                title: "Error!",
                                message: "Something went wrong!",
                                position: "topRight",
                                timeOut: 4000,
                            });
                        }
                    });
            } else {
                swal("Yout item is safe !");
            }
        });
    });

    $("#addForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

            var formdata = new FormData($("#addForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}addNewCoinPackages`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    if (response.code == "coin_packages_added") {
                        iziToast.success({
                            title: "Success!",
                            message: "Item Added successfully.",
                            position: "topRight",
                        });
                        $("#table-222").DataTable().ajax.reload(null, false);
                        $(".loader").hide();
                        $("#additem").modal("hide");
                        $("#addForm")[0].reset();
                    } else {
                        iziToast.error({
                            title: app.Error,
                            message: app.tester,
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
      
    });

    $("#table-222").on("click", ".edit", function (event) {
        event.preventDefault();

        $("#editForm")[0].reset();
        var id = $(this).attr("rel");

        $("#editId").val($(this).attr("rel"));

        var url = `${domainUrl}getCoinPackagesById` + "/" + id;

        $.getJSON(url).done(function (data) {
            var item = data;
            $("#package_name").val(item.coin_package_name);
            $("#coin_package_amount").val(item.coin_amount);
        });
        $("#edititem").modal("show");
    });

    $("#editForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

       
            var formdata = new FormData($("#editForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}editCoinPackages`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log("_____________________________________response ",response)
                    if (response.code == "coin_package_edit") {
                        iziToast.success({
                            title: "Success!",
                            message: "Item edited successfully.",
                            position: "topRight",
                        });
                        $("#table-222").DataTable().ajax.reload(null, false);
                        $(".loader").hide();
                        $("#edititem").modal("hide");
                        $("#editForm")[0].reset();
                    } else {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        
    });
});