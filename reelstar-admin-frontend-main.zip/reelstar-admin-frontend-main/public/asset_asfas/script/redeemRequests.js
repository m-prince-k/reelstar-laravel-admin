$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".redeemRequestsSideA").addClass("activeLi");

    $("#table-22").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchRedeemRequestsList`,
            data: function (data) {},
        },
    });

    $("#table-22").on("click", ".reject", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url =
                        `${domainUrl}rejectVerificationRequest` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-22").DataTable().ajax.reload(null, false);
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
    $("#table-22").on("click", ".complete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}completeRedeemRequest` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-22").DataTable().ajax.reload(null, false);
                    });

                     iziToast.success({
                         title: "Success!",
                         message: "Item Updated successfully.",
                         position: "topRight",
                     });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
});
