$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".coinPlansSideA").addClass("activeLi");

    $("#table-22").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchCoinPlansList`,
            data: function (data) {},
        },
    });

    $("#table-22").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}deleteCoinPlan` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-22").DataTable().ajax.reload(null, false);
                    });

                    iziToast.success({
                        title: "Success!",
                        message: "Item Deleted successfully.",
                        position: "topRight",
                    });
                } else {
                    iziToast.error({
                        title: "Error!",
                        message: "Something went wrong!",
                        position: "topRight",
                        timeOut: 4000,
                    });
                }
            } else {
                swal("Yout item is safe !");
            }
        });
    });

    $("#addForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#addForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}addNewCoinPlan`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-22").DataTable().ajax.reload(null, false);
                    $(".loader").hide();
                    $("#additem").modal("hide");
                    $("#addForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item Added successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#table-22").on("click", ".edit", function (event) {
        event.preventDefault();

        $("#editForm")[0].reset();
        var id = $(this).attr("rel");

        $("#editId").val($(this).attr("rel"));

        var url = `${domainUrl}getCoinPlanById` + "/" + id;

        $.getJSON(url).done(function (data) {
            var item = data;
            $("#edit_coin_amount").val(item.coin_amount);
            $("#edit_price").val(item.price);
            $("#edit_android_product_id").val(item.playstore_product_id);
            $("#edit_ios_product_id").val(item.appstore_product_id);
        });
        $("#edititem").modal("show");
    });

    $("#editForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#editForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}editCoinPlan`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-22").DataTable().ajax.reload(null, false);
                    $(".loader").hide();
                    $("#edititem").modal("hide");
                    $("#editForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item edited successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });
});
