$(document).ready(function(){
    $(".sideBarli").removeClass("activeLi");
    $(".coinpackageSideA").addClass("activeLi");

    function formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }

    $.getJSON(`${domainUrl}getEventData`).done(function(data) {
        console.log(data);
      var event = data.data;
    $('#event-name').val(event.name);
    $('#event-desc').val(event.description);
    var date = Date.parse(event.expiry_date);
    $('#event-expiry').val(formatDate(date));

    var targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + 20);
    var dd = targetDate.getDate();
    var mm = targetDate.getMonth() + 1; //January is 0!
    var yyyy = targetDate.getFullYear();

    targetDate = yyyy + '-'+`${mm < 10 ? '0' : ''}` + mm + '-' + dd;

    $('#event-expiry').attr('max', targetDate);


    if(event.status == 0){
        $('#featured').prop("checked", false);
    }else{
        $('#featured').prop("checked", true);

    }

    });


    $(document).on("change", "#featured", function(event) {

        event.preventDefault();

        if($(this).prop("checked") == true){
           var value = 1;
        }else{
            value = 0;
        }

        var updateEventStatusUrl = `${domainUrl}changeEventStatus`+"/"+value;

        $.getJSON(updateEventStatusUrl).done(function(data) {
            if(data.status){
                iziToast.success({
                    title: "Update Successful..",
                    message: "Event Updated Successfully !",
                    position: "topRight",
                });
            }else{
                iziToast.error({
                    title: "Something went wrong!",
                    message: "Data not updated !",
                    position: 'topRight'
                });
            }
        });

    });






    $("#table-22").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [1,2,3,4],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}getCoinPackageList`,
            data: function (data) {},
        },
    });

    $("#table-22").on("click",".delete-item",function(event) {

        event.preventDefault();
        swal({
                title: `${app.sure}`,
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    swal("Item Deleted Successfully", {
                        icon: "success",
                    });

                    if (user_type == "1") {
                        var element = $(this).parent();

                        var id = $(this).attr("rel");
                        var delete_cat_url = `${domainUrl}deleteCoinPackage`+"/"+id;

                        $.getJSON(delete_cat_url).done(function(data) {
                            console.log(data);
                            $('#table-22').DataTable().ajax.reload(null, false);
                        });
                    } else {
                        iziToast.error({
                            title: app.Error,
                            message: app.tester,
                            position: 'topRight'
                        });
                    }

                } else {
                    swal("Yout item is safe !");
                }
            });


    });

    $("#manageEvent").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#manageEvent")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}updateEventData`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-22").DataTable().ajax.reload(null, false);
                    $(".loader").hide();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    }else{
                        iziToast.success({
                            title: "Update Successful..",
                            message: "Event Updated Successfully !",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });


    $("#addForm").on("submit", function (event) {
        event.preventDefault();
        //$(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#addForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}addCoinPackage`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-22").DataTable().ajax.reload(null, false);
                    $(".loader").hide();
                    $("#additem").modal("hide");
                    $("#addForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#table-22").on("click",".edit-item",function(event) {
        event.preventDefault();

        $('#editForm')[0].reset();
        var  id = $(this).attr('rel');

        $('#editId').val($(this).attr('rel'));

        var url =  `${domainUrl}getCoinPlanById`+"/"+id;

        $.getJSON(url).done(function(data) {
            console.log(data);

            $('#edit_coin_amount').val(data.coin_amount);
            $('#edit_extra_coin_amount').val(data.extra_coin_amount);
            $('#edit_price').val(data.price);
            $('#edit_android_product_id').val(data.android_product_id);
            $('#edit_ios_product_id').val(data.ios_product_id);

        });
        $('#edititem').modal('show');
    });

    $("#editForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#editForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}editCoinPlan`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-22").DataTable().ajax.reload(null, false);
                    $(".loader").hide();
                    $("#edititem").modal("hide");
                    $("#editForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });


})
