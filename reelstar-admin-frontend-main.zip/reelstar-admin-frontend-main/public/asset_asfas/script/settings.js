$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".settingsSideA").addClass("activeLi");

    $(document).on("change", "#adsSwitch", function (event) {
        event.preventDefault();

        if ($(this).prop("checked") == true) {
            var value = 1;
        } else {
            value = 0;
        }

        var updateEventStatusUrl =
            `${domainUrl}changeShowAdsStatus` + "/" + value;

        $.getJSON(updateEventStatusUrl).done(function (data) {
            if (data.status) {
                iziToast.success({
                    title: "Update Successful..",
                    message: "Settings Updated Successfully !",
                    position: "topRight",
                });
            } else {
                iziToast.error({
                    title: "Failed!",
                    message: "Something went wrong!",
                    position: "topRight",
                });
            }
        });
    });
    $(document).on("change", "#deepARSwitch", function (event) {
        event.preventDefault();

        if ($(this).prop("checked") == true) {
            var value = 1;
        } else {
            value = 0;
        }

        var updateEventStatusUrl =
            `${domainUrl}changeDeepARStatus` + "/" + value;

        $.getJSON(updateEventStatusUrl).done(function (data) {
            if (data.status) {
                iziToast.success({
                    title: "Update Successful..",
                    message: "Settings Updated Successfully !",
                    position: "topRight",
                });
            } else {
                iziToast.error({
                    title: "Failed!",
                    message: "Something went wrong!",
                    position: "topRight",
                });
            }
        });
    });
    $(document).on("change", "#multipleLivestreamSwitch", function (event) {
        event.preventDefault();

        if ($(this).prop("checked") == true) {
            var value = 1;
        } else {
            value = 0;
        }

        var updateEventStatusUrl =
            `${domainUrl}changeMultiLivestreamStatus` + "/" + value;

        $.getJSON(updateEventStatusUrl).done(function (data) {
            if (data.status) {
                iziToast.success({
                    title: "Update Successful..",
                    message: "Settings Updated Successfully !",
                    position: "topRight",
                });
            } else {
                iziToast.error({
                    title: "Failed!",
                    message: "Something went wrong!",
                    position: "topRight",
                });
            }
        });
    });

    $("#globalSettingsForm").on("submit", function (event) {
        event.preventDefault();
        if (user_type == "1") {
            var formdata = new FormData($("#globalSettingsForm")[0]);
            $.ajax({
                url: domainUrl + "updateGlobalSettings",
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    // $(".loader").hide();
                    location.reload();
                },
                error: (error) => {
                    $(".loader").hide();
                    console.log(JSON.stringify(error));
                },
            });
        } else {
            $(".loader").hide();
            iziToast.error({
                title: "Error!",
                message: " you are Tester ",
                position: "topRight",
            });
        }
    });

    $("#addRedeemGateForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#addRedeemGateForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}addRedeemGateway`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-redeem-gateways")
                        .DataTable()
                        .ajax.reload(null, false);
                    $(".loader").hide();
                    $("#addRedeemGateitem").modal("hide");
                    $("#addRedeemGateForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item added successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });
    $("#addReportReasonForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#addReportReasonForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}addReportReason`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-report-reasons")
                        .DataTable()
                        .ajax.reload(null, false);
                    $(".loader").hide();
                    $("#addReportReasonitem").modal("hide");
                    $("#addReportReasonForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item added successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });
    $("#editReportReasonForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#editReportReasonForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}editReportReason`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-report-reasons")
                        .DataTable()
                        .ajax.reload(null, false);
                    $(".loader").hide();
                    $("#editReportReasonitem").modal("hide");
                    $("#editReportReasonForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item updated successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });
    $("#editRedeemGatewayForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#editRedeemGatewayForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}editRedeemGateway`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-redeem-gateways")
                        .DataTable()
                        .ajax.reload(null, false);
                    $(".loader").hide();
                    $("#editRedeemGatewayItem").modal("hide");
                    $("#editRedeemGatewayForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item edited successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#table-redeem-gateways").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchRedeemGatewayList`,
            data: function (data) {},
        },
    });
    $("#table-profile-cats").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchProfileCategoriesList`,
            data: function (data) {},
        },
    });

    $("#table-report-reasons").dataTable({
        processing: true,
        serverSide: true,
        bFilter: false,
        bInfo: false,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchReportReasonsList`,
            data: function (data) {},
        },
    });
    $("#table-gifts").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchGiftsList`,
            data: function (data) {},
        },
    });
    $("#table-verify-docs").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1],
                orderable: false,
            },
        ],
        ajax: {
            url: `${domainUrl}fetchVerifyDocsList`,
            data: function (data) {},
        },
    });
    $("#addVerifyDocForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#addVerifyDocForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}addVerifyDocs`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-verify-docs")
                        .DataTable()
                        .ajax.reload(null, false);
                    $(".loader").hide();
                    $("#addVerifyDocitem").modal("hide");
                    $("#addVerifyDocForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item added successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#editGiftForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#editGiftForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}editGift`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-gifts").DataTable().ajax.reload(null, false);
                    $(".loader").hide();
                    $("#editGiftitem").modal("hide");
                    $("#editGiftForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item updated successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });
    $("#addGiftForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#addGiftForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}addGift`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-gifts").DataTable().ajax.reload(null, false);
                    $(".loader").hide();
                    $("#addGiftitem").modal("hide");
                    $("#addGiftForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item added successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#table-verify-docs").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}deleteVerifyDoc` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-verify-docs")
                            .DataTable()
                            .ajax.reload(null, false);
                        iziToast.success({
                            title: "Success!",
                            message: "Item deleted successfully.",
                            position: "topRight",
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });

    $("#table-gifts").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}deleteGift` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-gifts").DataTable().ajax.reload(null, false);
                        iziToast.success({
                            title: "Success!",
                            message: "Item deleted successfully.",
                            position: "topRight",
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });

    $("#table-gifts").on("click", ".edit", function (event) {
        event.preventDefault();
        $("#editGiftForm")[0].reset();

        var price = $(this).data("price");
        var image = $(this).data("image");

        $("#edit_coin_price").val(price);
        $("#gift-img-view").attr("src", image);
        $("#editGiftId").val($(this).attr("rel"));
        $("#editGiftitem").modal("show");
    });
    $("#table-redeem-gateways").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}deleteRedeemGateway` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-redeem-gateways")
                            .DataTable()
                            .ajax.reload(null, false);
                        iziToast.success({
                            title: "Success!",
                            message: "Item deleted successfully.",
                            position: "topRight",
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });

    $("#table-redeem-gateways").on("click", ".edit", function (event) {
        event.preventDefault();
        $("#editRedeemGatewayForm")[0].reset();
        var title = $(this).data("gateway");
        $("#edit_gateway").val(title);
        $("#editRedeemGatewayId").val($(this).attr("rel"));

        $("#editRedeemGatewayItem").modal("show");
    });

    $("#table-report-reasons").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}deleteReportReason` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-report-reasons")
                            .DataTable()
                            .ajax.reload(null, false);

                        iziToast.success({
                            title: "Success!",
                            message: "Item deleted successfully.",
                            position: "topRight",
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });
    $("#table-report-reasons").on("click", ".edit", function (event) {
        event.preventDefault();
        $("#editReportReasonForm")[0].reset();
        var title = $(this).data("reason");
        $("#edit_report_reason").val(title);
        $("#editReportReasonId").val($(this).attr("rel"));

        $("#editReportReasonitem").modal("show");
    });

    $("#addProfileCatForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#addProfileCatForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}addProfileCategory`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-profile-cats")
                        .DataTable()
                        .ajax.reload(null, false);
                    $(".loader").hide();
                    $("#addProfileCatitem").modal("hide");
                    $("#addProfileCatForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item added successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#editProfileCatForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#editProfileCatForm")[0]);
            console.log(formdata);

            $.ajax({
                url: `${domainUrl}editProfileCategory`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    $("#table-profile-cats")
                        .DataTable()
                        .ajax.reload(null, false);
                    $(".loader").hide();
                    $("#editProfileCatitem").modal("hide");
                    $("#editProfileCatForm")[0].reset();

                    if (response.status == false) {
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    } else {
                        iziToast.success({
                            title: "Success!",
                            message: "Item updated successfully.",
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    $("#table-profile-cats").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var id = $(this).attr("rel");
                    var url = `${domainUrl}deleteProfileCategory` + "/" + id;

                    $.getJSON(url).done(function (data) {
                        console.log(data);
                        $("#table-profile-cats")
                            .DataTable()
                            .ajax.reload(null, false);
                        iziToast.success({
                            title: "Success!",
                            message: "Item deleted successfully.",
                            position: "topRight",
                        });
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });

    $("#table-profile-cats").on("click", ".edit", function (event) {
        event.preventDefault();

        $("#editProfileCatForm")[0].reset();
        var title = $(this).data("title");
        var imgUrl = $(this).data("image");

        $("#editProfileCatId").val($(this).attr("rel"));
        $("#edit_title").val(title);
        $("#profile-cat-img-view").attr("src", imgUrl);

        $("#editProfileCatitem").modal("show");
    });

    var editProfileCatImageInput = $("#edit_profile_cat_image");
    editProfileCatImageInput.change(function () {
        if (
            editProfileCatImageInput[0].files &&
            editProfileCatImageInput[0].files[0]
        ) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $("#profile-cat-img-view").attr("src", e.target.result);
            };
            reader.readAsDataURL(editProfileCatImageInput[0].files[0]);
            console.log(editProfileCatImageInput[0].files[0]);
        }
    });

    var editGiftImageInput = $("#gift_image");
    editGiftImageInput.change(function () {
        if (editGiftImageInput[0].files && editGiftImageInput[0].files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $("#gift-img-view").attr("src", e.target.result);
            };
            reader.readAsDataURL(editGiftImageInput[0].files[0]);
            console.log(editGiftImageInput[0].files[0]);
        }
    });
});
