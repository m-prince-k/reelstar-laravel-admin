$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");

    var userId = $("#userId").val();

    // var formData = new FormData();
    // formData.append("id", userId);

    $("#viewPostByUser").dataTable({
        processing: true,
        serverSide: true,
        serverMethod: "post",
        aaSorting: [[0, "desc"]],
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4, 5, 6, 7, 8],
                orderable: false,
                
            },
        ],
        ajax: {
            url: `${domainUrl}fetchUserPostList`,
            type: "POST",
            data: jQuery.param({userId:userId}),
            dataType: "json",
            //contentType: false,
            cache: false,
            //processData: false,

            data: function (data) {
                data.userId = userId;
                console.log(data);
            },
        },
    });

    $("#userPostTable").on("click", ".view-content", function (event) {
        event.preventDefault();
        var contentUrl = $(this).data("url");
        var description = $(this).data("description");

        $("#videoDesc").text(description);
        $("#video source").attr("src", contentUrl);
        $("#video")[0].load();
        $("#video_modal").modal("show");
        $("#video").trigger("play");
    });

    $("#video_modal").on("hidden.bs.modal", function () {
        $("#video").trigger("pause");
    });

    $("#userPostTable").on("click", ".delete", function (event) {
        event.preventDefault();
        swal({
            title: "Do you really want to continue?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                if (user_type == "1") {
                    var post_id = $(this).attr("rel");
                    var user_id = $(this).attr("data-userId");
                    var url = `${domainUrl}deletePost`;
                    var formdata = new FormData();
                    formdata.append("user_id", user_id);
                    formdata.append("post_id", post_id);

                    // console.log(post_id);
                    // console.log(user_id);

                    $.ajax({
                        url: url,
                        type: "POST",
                        data: formdata,
                        dataType: "json",
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (response) {
                            console.log(response);

                            $("#userPostTable")
                                .DataTable()
                                .ajax.reload(null, false);

                            if (response.status == false) {
                                iziToast.error({
                                    title: app.Error,
                                    message: response.message,
                                    position: "topRight",
                                });
                            } else {
                                iziToast.success({
                                    title: "Success!",
                                    message: "Post deleted successfully.",
                                    position: "topRight",
                                });
                            }
                        },
                        error: function (err) {
                            console.log(err);
                        },
                    });
                } else {
                    iziToast.error({
                        title: app.Error,
                        message: app.tester,
                        position: "topRight",
                    });
                }
            }
        });
    });

    $("#enable_live").on("click", function (event) {
        event.preventDefault();

        var url = `${domainUrl}enableLiveStreamingToUser` + "/" + userId;
        $(".loader").show();

        $.getJSON(url).done(function (data) {
            console.log(data);
            location.reload();
        });
    });
    $("#disable_live").on("click", function (event) {
        event.preventDefault();

        var url = `${domainUrl}disableLiveStreamingToUser` + "/" + userId;
        $(".loader").show();

        $.getJSON(url).done(function (data) {
            console.log(data);
            location.reload();
        });
    });
    $("#enable_sponsor").on("click", function (event) {
        event.preventDefault();

        var url = `${domainUrl}enableSponsored` + "/" + userId;
        $(".loader").show();

        $.getJSON(url).done(function (data) {
            console.log(data);
            location.reload();
        });
    });
    $("#disable_sponsor").on("click", function (event) {
        event.preventDefault();

        var url = `${domainUrl}disableSponsored` + "/" + userId;
        $(".loader").show();

        $.getJSON(url).done(function (data) {
            console.log(data);
            location.reload();
        });
    });
    $("#video_modal").on("hidden.bs.modal", function () {
        $("#video").trigger("pause");
    });
    $("#imagemodal").on("hidden.bs.modal", function () {
        $("#indicator-place").empty();
        $("#image-place").empty();
    });

    $(document).on("click", ".removeimg", function (event) {
        event.preventDefault();
        $countimg = $(".removeimg").length;

        if ($countimg <= 1) {
            iziToast.error({
                title: `${app.Error}!`,
                message: `${app.minimumImage}`,
                position: "topRight",
            });
        } else {
            swal({
                title: `${app.sure}`,
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    swal("Item Deleted Successfully", {
                        icon: "success",
                    });

                    var element = $(this).parent();
                    var id = $(this).attr("rel");
                    var delete_url = `${domainUrl}deletUserImage` + "/" + id;
                    $.getJSON(delete_url).done(function (data) {
                        console.log(data);
                    });
                    $(this).parent().parent().remove();
                } else {
                    swal("Yout item is safe !");
                }
            });
        }
    });

    $(document).on("click", ".add-coin", function (event) {
        event.preventDefault();
        $("#addCoinModal").modal("show");
        $("#addcoinUserId").val(userId);
        console.log($("#addcoinUserId").val());
    });
    $(document).on("click", ".verify-user", function (event) {
        event.preventDefault();

        swal({
            title: `${app.sure}`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                var url = `${domainUrl}verifyUserFromAdmin` + "/" + userId;
                $.getJSON(url).done(function (data) {
                    console.log(data);
                    location.reload();
                });
            } else {
                swal("No Changes made !");
            }
        });
    });

    // Edit User
    $(".edit-user").on("click", function (event) {
        event.preventDefault();
        $("#editUserItem").modal("show");
    });

    $("#editUserForm").on("submit", function (event) {
        event.preventDefault();
        //$(".loader").show();
       
            //var formdata = new FormData($("#editUserForm")[0]);

            $.ajax({
                url: `${domainUrl}editUserFromAdmin`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log("___________________________",response);
                    $(".loader").hide();
                    // $("#editUserModal").modal("hide");
                    // $("#editUserForm")[0].reset();

                    // if (response.status == true) {
                    //     location.reload();
                    // } else {
                    //     $(".loader").hide();
                    //     iziToast.error({
                    //         title: app.Error,
                    //         message: response.message,
                    //         position: "topRight",
                    //     });
                    // }
                },
                error: function (err) {
                    console.log("_________________________",err);
                },
            });
       
    });

    $("#addImagesForm").on("submit", function (event) {
        event.preventDefault();
        $(".loader").show();

        if (user_type == "1") {
            var formdata = new FormData($("#addImagesForm")[0]);

            $.ajax({
                url: `${domainUrl}addUserImagesFromAdmin`,
                type: "POST",
                data: formdata,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function (response) {
                    console.log(response);
                    // $(".loader").hide();
                    // $("#editUserModal").modal("hide");
                    // $("#editUserForm")[0].reset();

                    if (response.status == true) {
                        location.reload();
                    } else {
                        $(".loader").hide();
                        iziToast.error({
                            title: app.Error,
                            message: response.message,
                            position: "topRight",
                        });
                    }
                },
                error: function (err) {
                    console.log(err.message);
                },
            });
        } else {
            iziToast.error({
                title: app.Error,
                message: app.tester,
                position: "topRight",
            });
        }
    });

    var editProfileImageInput = $("#profile_image");
    editProfileImageInput.change(function () {
        if (
            editProfileImageInput[0].files &&
            editProfileImageInput[0].files[0]
        ) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $("#profile_img_preview").attr("src", e.target.result);
            };
            reader.readAsDataURL(editProfileImageInput[0].files[0]);
            console.log(editProfileImageInput[0].files[0]);
        }
    });
});
